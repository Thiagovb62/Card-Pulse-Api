CREATE TABLE account
(
    id                     UUID PRIMARY KEY,
    card_token             VARCHAR(100) UNIQUE NOT NULL,
    balance                NUMERIC(19, 2)      NOT NULL CHECK (balance >= 0),
    available_credit_limit NUMERIC(19, 2)      NOT NULL CHECK (available_credit_limit >= 0)
);


CREATE TABLE transactions
(

    id                    UUID PRIMARY KEY,
    idempotency_key       VARCHAR(255)   NOT NULL UNIQUE,
    origin_transaction_id VARCHAR(100)   NOT NULL,
    card_token            VARCHAR(100)   NOT NULL,
    transaction_type      VARCHAR(20)    NOT NULL CHECK (transaction_type IN ('DEBITO', 'CREDITO')),
    amount                NUMERIC(19, 2) NOT NULL,
    currency              VARCHAR(3)     NOT NULL,
    merchant_id           VARCHAR(100)   NOT NULL,

    status                VARCHAR(20)    NOT NULL CHECK (status IN ('RECEBIDA',
                                                                    'APROVADA',
                                                                    'CAPTURADA',
                                                                    'NEGADA',
                                                                    'CANCELADA',
                                                                    'REVERTIDA')),

    correlation_id        VARCHAR(255)   NOT NULL,
    occurred_at           TIMESTAMP      NOT NULL,
    received_at           TIMESTAMP      NOT NULL,
    decided_at            TIMESTAMP,
    reason_code           VARCHAR(50),
    reason                VARCHAR(255),
    created_at            TIMESTAMP      NOT NULL,
    CONSTRAINT fk_transaction_account
        FOREIGN KEY (card_token)
            REFERENCES account (card_token)
);

CREATE TABLE outbox_events
(
    id             UUID PRIMARY KEY,
    transaction_id UUID         NOT NULL,
    event_type     VARCHAR(100) NOT NULL,
    payload        JSONB        NOT NULL,
    status         VARCHAR(20)  NOT NULL,
    retry_count    INTEGER DEFAULT 0,
    created_at     TIMESTAMP    NOT NULL,
    published_at   TIMESTAMP,
    CONSTRAINT fk_transaction
        FOREIGN KEY (transaction_id)
            REFERENCES transactions (id)

);



CREATE TABLE idempotency_keys
(
    id               BIGSERIAL PRIMARY KEY,
    idempotency_key  VARCHAR(255)   NOT NULL UNIQUE,
    valor            NUMERIC(19, 4) NOT NULL,
    currency_used    VARCHAR(50)    NOT NULL,
    usuario_id       BIGINT         NOT NULL,
    destination      VARCHAR(255)   NOT NULL,
    type             VARCHAR(50)    NOT NULL,
    hora             TIMESTAMP      NOT NULL,
    expires_at       TIMESTAMP      NOT NULL,
    authorization_id UUID           NOT NULL,
    status           VARCHAR(50)    NOT NULL,
    received_at      TIMESTAMP      NOT NULL,
    correlation_id   VARCHAR(255)   NOT NULL,
    decided_at       TIMESTAMP      NOT NULL,
    reason           VARCHAR(255)   NOT NULL,
    reason_code      VARCHAR(255)   NOT NULL,
    operation_id     VARCHAR(255),

    CONSTRAINT uk_idempotency_key
        UNIQUE (idempotency_key)
);

