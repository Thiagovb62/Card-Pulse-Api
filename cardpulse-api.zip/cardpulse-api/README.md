# CardPulse 💳

Sistema de autorização de transações financeiras desenvolvido com **Java 21**, **Spring Boot**, **PostgreSQL**, **MongoDB** e **Kafka**, seguindo os princípios da **Arquitetura Hexagonal**.

## 🎯 Objetivo

Permitir o recebimento e processamento seguro de solicitações de autorização, garantindo:

- Idempotência
- Rastreabilidade por Correlation ID
- Consistência transacional
- Evolução para auditoria e eventos
- Independência entre domínio e infraestrutura

---

## 🏗️ Arquitetura

O projeto segue o padrão **Ports and Adapters (Hexagonal Architecture)**.

```text
Controller
    ↓
Use Cases
    ↓
Domain
    ↓
Repositories / Adapters
```

### Tecnologias

- Java 21
- Spring Boot 3
- Maven
- PostgreSQL
- MongoDB
- Apache Kafka
- OpenAPI / Swagger
- JUnit 5
- Mockito

---

## ✅ Funcionalidades Implementadas

### História 1 - Recebimento e Idempotência

- Recebimento de transações via API REST
- Validação de dados obrigatórios
- Geração automática de Correlation ID
- Persistência da autorização
- Registro de solicitações
- Controle de idempotência
- Retorno de respostas já processadas

### História 2 - Débito

- Processamento de transações DEBITO
- Validação de saldo disponível
- Aprovação ou negação da transação
- Registro da decisão
- Proteção contra processamento duplicado
- Persistência transacional

### História 3 - Crédito

🚧 Em desenvolvimento

---

## 🔑 Idempotência

Cada requisição deve possuir um header:

```http
Idempotency-Key
```

Caso uma mesma solicitação seja enviada novamente dentro da janela válida de retenção:

- Nenhum novo processamento é realizado
- Nenhum novo impacto financeiro ocorre
- A resposta original é retornada

---

## 🔍 Correlation ID

Header opcional:

```http
X-Correlation-ID
```

Caso não seja informado, um identificador é gerado automaticamente.

Utilizado para:

- Logs
- Auditoria
- Rastreabilidade
- Eventos

---

## 📡 Endpoint

### Processar autorização

```http
PUT /api/v1/authorizations
```

### Headers

```http
Idempotency-Key: <valor>
X-Correlation-ID: <opcional>
```

### Exemplo de Requisição

```json
{
  "originTransactionId": "TXN-001",
  "cardToken": "CARD-TOKEN-123",
  "transactionType": "DEBITO",
  "amount": 100.00,
  "currency": "BRL",
  "merchantId": "MERCADO-01",
  "occurredAt": "2026-09-11T10:00:00Z"
}
```

---

## 🧪 Testes

O projeto possui testes automatizados utilizando:

- JUnit 5
- Mockito

### Executar testes

```bash
mvn test
```

### Build completo

```bash
mvn clean verify
```

---

## 📚 Swagger

Após iniciar a aplicação:

```text
http://localhost:8080/swagger-ui/index.html
```

---


**CardPulse** foi desenvolvido com foco em consistência financeira, rastreabilidade, qualidade de código e evolução incremental utilizando Arquitetura Hexagonal.