package com.start.cardpulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardPulseApplicationTests {

    @Test
    void contextLoads() {
    }

}
