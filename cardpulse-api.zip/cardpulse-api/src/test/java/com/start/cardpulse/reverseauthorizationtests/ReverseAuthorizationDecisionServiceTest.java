package com.start.cardpulse.reverseauthorizationtests;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.repository.AccountRepository;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.ports.out.AuthorizationAuditPort;
import com.start.cardpulse.application.service.ReverseAuthorizationDecisionService;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;
import com.start.cardpulse.domain.enums.TransactionType;
import com.start.cardpulse.domain.exception.AuthorizationNotApprovedException;
import com.start.cardpulse.domain.exception.AuthorizationNotFoundException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReverseAuthorizationDecisionServiceTest {


    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private AccountRepository accountRepository;

    @InjectMocks
    private ReverseAuthorizationDecisionService service;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private AuthorizationAuditPort auditPort;

    @Mock
    private OutboxEventRepository outboxEventRepository;

    @Test
    void shouldRevertApprovedDebitAuthorization() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createApprovedDebitTransaction(
                        authorizationId,
                        BigDecimal.valueOf(100)
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));


        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"REVERTIDA\"}");


        TransactionReleaseResponse response =
                service.execute(authorizationId, createRequest());

        verify(accountRepository)
                .restoreBalance(
                        "card-123",
                        BigDecimal.valueOf(100)
                );

        Assertions.assertEquals(
                AuthorizationStatus.REVERTIDA,
                response.status());

        Assertions.assertEquals(
                ReasonCode.REVERSION_APPROVED,
                response.reasonCode());

        Assertions.assertFalse(response.idempotentReplay());

        verify(auditPort).save(any());
        verify(outboxEventRepository)
                .save(any(OutboxEvent.class));
    }

    @Test
    void shouldRevertApprovedCreditAuthorization() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createApprovedCreditTransaction(
                        authorizationId,
                        BigDecimal.valueOf(200)
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"REVERTIDA\"}");

        service.execute(authorizationId, createRequest());

        verify(accountRepository)
                .restoreCreditLimit(
                        "card-123",
                        BigDecimal.valueOf(200)
                );

        verify(accountRepository, never())
                .restoreBalance(any(), any());


        verify(auditPort).save(any());
        verify(outboxEventRepository)
                .save(any(OutboxEvent.class));
    }

    @Test
    void shouldThrowExceptionWhenAuthorizationNotFound() {

        UUID authorizationId = UUID.randomUUID();

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.empty());

        Assertions.assertThrows(
                AuthorizationNotFoundException.class,
                () -> service.execute(authorizationId, createRequest())
        );
    }

    @Test
    void shouldRejectReversionWhenAuthorizationIsReceived() {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction = new Transaction();
        transaction.setStatus(AuthorizationStatus.RECEBIDA);

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        Assertions.assertThrows(
                AuthorizationNotApprovedException.class,
                () -> service.execute(authorizationId, createRequest())
        );

        verifyNoInteractions(accountRepository);
    }

    @Test
    void shouldRejectReversionWhenAuthorizationIsDenied() {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction = new Transaction();
        transaction.setStatus(AuthorizationStatus.NEGADA);

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        Assertions.assertThrows(
                AuthorizationNotApprovedException.class,
                () -> service.execute(authorizationId, createRequest())
        );

        verifyNoInteractions(accountRepository);
    }

    @Test
    void shouldRejectReversionWhenAuthorizationAlreadyCancelled() {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction = new Transaction();
        transaction.setStatus(AuthorizationStatus.REVERTIDA);

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        Assertions.assertThrows(
                AuthorizationNotApprovedException.class,
                () -> service.execute(authorizationId, createRequest())
        );

        verifyNoInteractions(accountRepository);
    }

    @Test
    void shouldNotAllowIdempotentReplayAfterReversion() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createApprovedDebitTransaction(
                        authorizationId,
                        BigDecimal.valueOf(100)
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));


        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"NEGADA\"}");

        service.execute(authorizationId, createRequest());

        Assertions.assertEquals(
                AuthorizationStatus.REVERTIDA,
                transaction.getStatus());

        Assertions.assertThrows(
                AuthorizationNotApprovedException.class,
                () -> service.execute(authorizationId, createRequest())
        );

        verify(accountRepository, times(1))
                .restoreBalance(
                        "card-123",
                        BigDecimal.valueOf(100)
                );
    }

    @Test
    void shouldPreserveMonetaryPrecisionWhenRestoringDebitBalance() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        BigDecimal amount =
                new BigDecimal("100.99");

        Transaction transaction =
                createApprovedDebitTransaction(
                        authorizationId,
                        amount
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));


        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"REVERTIDA\"}");

        service.execute(authorizationId, createRequest());

        verify(accountRepository)
                .restoreBalance(
                        "card-123",
                        amount
                );


        verify(auditPort).save(any());
        verify(outboxEventRepository)
                .save(any(OutboxEvent.class));

        Assertions.assertEquals(
                amount,
                transaction.getAmount()
        );
    }

    @Test
    void shouldPreserveMonetaryPrecisionWhenRestoringCreditLimit() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        BigDecimal amount =
                new BigDecimal("999999.99");

        Transaction transaction =
                createApprovedCreditTransaction(
                        authorizationId,
                        amount
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));


        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"REVERTIDA\"}");

        service.execute(authorizationId, createRequest());

        verify(accountRepository)
                .restoreCreditLimit(
                        "card-123",
                        amount
                );


        verify(auditPort).save(any());
        verify(outboxEventRepository)
                .save(any(OutboxEvent.class));
    }


    private Transaction createApprovedDebitTransaction(
            UUID authorizationId,
            BigDecimal amount) {

        Transaction transaction = new Transaction();

        transaction.setId(authorizationId);
        transaction.setStatus(AuthorizationStatus.APROVADA);
        transaction.setTransactionType(TransactionType.DEBITO);
        transaction.setCardToken("card-123");
        transaction.setAmount(amount);

        return transaction;
    }

    private Transaction createApprovedCreditTransaction(
            UUID authorizationId,
            BigDecimal amount) {

        Transaction transaction = new Transaction();

        transaction.setId(authorizationId);
        transaction.setStatus(AuthorizationStatus.APROVADA);
        transaction.setTransactionType(TransactionType.CREDITO);
        transaction.setCardToken("card-123");
        transaction.setAmount(amount);

        return transaction;
    }

    private TransactionReleaseRequest createRequest() {
        return new TransactionReleaseRequest(
                "OP-123",
                "Sistema Instável"
        );
    }
}
