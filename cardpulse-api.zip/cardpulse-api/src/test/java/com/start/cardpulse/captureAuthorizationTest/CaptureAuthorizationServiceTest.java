package com.start.cardpulse.captureAuthorizationTest;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.repository.CaptureAuthorizationRepository;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.ports.out.AuthorizationAuditPort;
import com.start.cardpulse.application.service.CaptureAuthorizationService;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationRequest;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.exception.InvalidAuthorizationStatusException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tools.jackson.databind.ObjectMapper;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.UUID;

import static com.start.cardpulse.domain.enums.AuthorizationStatus.CAPTURADA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class CaptureAuthorizationServiceTest {
    @Mock
    TransactionRepository transactionRepository;

    @Mock
    CaptureAuthorizationRepository captureAuthorizationRepository;

    @Mock
    AuthorizationAuditPort auditPort;

    @Mock
    OutboxEventRepository eventRepository;

    @Mock
    ObjectMapper objectMapper;

    @InjectMocks
    CaptureAuthorizationService service;

    private Transaction buildApprovedTransaction() {
        Transaction transaction = new Transaction();
        transaction.setId(UUID.randomUUID());
        transaction.setStatus(AuthorizationStatus.APROVADA);
        transaction.setAmount(BigDecimal.valueOf(100));
        transaction.setCurrency("BRL");

        return transaction;
    }

    @Test
    void shouldCaptureAuthorizationSucessfully() {

        UUID transactionId = UUID.randomUUID();

        Transaction transaction = buildApprovedTransaction();

        CaptureAuthorizationRequest request = new CaptureAuthorizationRequest(transactionId,
                "CAPTURE-001",
                BigDecimal.valueOf(10),
                "BRL",
                OffsetDateTime.now());

        when(transactionRepository.findById(transactionId)).thenReturn(Optional.of(transaction));

        when(captureAuthorizationRepository.changeStatus(transactionId, AuthorizationStatus.APROVADA, CAPTURADA)).
                thenReturn(1);

        when(objectMapper.writeValueAsString(any())).thenReturn("{\"status\":\"CAPTURADA\"}");

        CaptureAuthorizationResponse response = service.execute(
                request,
                "IDEM-001",
                "CORRE-001"
        );

        assertEquals(CAPTURADA, response.status());

        verify(auditPort).save(any());

        verify(eventRepository).save(any());
    }

    @Test
    void shouldTheowWhenConcurrentUpdateFails() {
        UUID transactionId = UUID.randomUUID();

        Transaction transaction = buildApprovedTransaction();

        CaptureAuthorizationRequest request = new CaptureAuthorizationRequest(
                transactionId,
                "CAPTURE-001",
                BigDecimal.valueOf(10),
                "BRL", OffsetDateTime.now());

        when(transactionRepository.findById(transactionId)).thenReturn(Optional.of(transaction));

        when(captureAuthorizationRepository.changeStatus(transactionId, AuthorizationStatus.APROVADA, CAPTURADA))
                .thenReturn(1);

        assertThrows(InvalidAuthorizationStatusException.class, () -> service.execute(
                request,
                "IDEM-001",
                "CORRE-001"));

        verify(auditPort, never()).save(any());
        verify(eventRepository, never()).save(any());

    }


}
