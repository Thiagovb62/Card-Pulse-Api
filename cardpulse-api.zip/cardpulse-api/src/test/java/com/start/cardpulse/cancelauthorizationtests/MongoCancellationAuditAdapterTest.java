package com.start.cardpulse.cancelauthorizationtests;


import com.start.cardpulse.adapters.outbound.mongo.adapter.MongoAuthorizationAuditAdapter;
import com.start.cardpulse.adapters.outbound.mongo.document.AuthorizationAuditDocument;
import com.start.cardpulse.adapters.outbound.mongo.repository.AuthorizationAuditRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class MongoCancellationAuditAdapterTest {

    @Mock
    private AuthorizationAuditRepository repository;

    @InjectMocks
    private MongoAuthorizationAuditAdapter adapter;

    @Test
    void shouldSaveAuditDocument() {

        AuthorizationAuditDocument audit =
                new AuthorizationAuditDocument(
                        UUID.randomUUID(),
                        "AUTHORIZATION_CANCELLED",
                        "APROVADA",
                        "CANCELADA",
                        "CANCELLATION_APPROVED",
                        Instant.now(),
                        "corr-123"
                );

        adapter.save(audit);

        verify(repository).save(audit);
    }

    @Test
    void shouldThrowExceptionWhenMongoFails() {

        AuthorizationAuditDocument audit =
                new AuthorizationAuditDocument(
                        UUID.randomUUID(),
                        "AUTHORIZATION_CANCELLED",
                        "APROVADA",
                        "CANCELADA",
                        "CANCELLATION_APPROVED",
                        Instant.now(),
                        "corr-123"
                );

        when(repository.save(any()))
                .thenThrow(new RuntimeException("Mongo error"));

        assertThrows(
                RuntimeException.class,
                () -> adapter.save(audit)
        );
    }

}
