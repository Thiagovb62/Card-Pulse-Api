package com.start.cardpulse.reverseauthorizationtests;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.start.cardpulse.adapters.outbound.entities.Account;
import com.start.cardpulse.adapters.outbound.repository.AccountRepository;
import com.start.cardpulse.domain.dto.transaction.TransactionRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.enums.TransactionType;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest
@AutoConfigureMockMvc
@Transactional
public class ReverseAuthorizationIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private String cardToken;


    @BeforeEach
    void setup() {

        cardToken = "CARD_TEST_" + UUID.randomUUID();

        Account account = new Account(
                UUID.randomUUID(),
                cardToken,
                new BigDecimal("1000.00"),
                new BigDecimal("5000.00")
        );

        accountRepository.save(account);
    }

    @Test
    void shouldCancelAuthorization() throws Exception {

        TransactionRequest authorizationRequest =
                new TransactionRequest(
                        UUID.randomUUID().toString(),
                        cardToken,
                        TransactionType.DEBITO,
                        new BigDecimal("100.00"),
                        "BRL",
                        "LOJA_001",
                        Instant.now().toString()
                );

        String authorizationResponse =
                mockMvc.perform(
                                put("/api/v1/authorizations")
                                        .header("Idempotency-Key", UUID.randomUUID().toString())
                                        .header("Correlation-Id", UUID.randomUUID().toString())
                                        .contentType(MediaType.APPLICATION_JSON)
                                        .content(objectMapper.writeValueAsString(authorizationRequest))
                        )
                        .andExpect(status().isOk())
                        .andReturn()
                        .getResponse()
                        .getContentAsString();

        JsonNode json = objectMapper.readTree(authorizationResponse);

        UUID authorizationId =
                UUID.fromString(json.get("authorizationId").asText());

        String operationId = UUID.randomUUID().toString();

        TransactionReleaseRequest request =
                new TransactionReleaseRequest(
                        operationId,
                        "Reversão de autorização"
                );

        mockMvc.perform(
                        post("/api/v1/authorizations/{authorizationId}/reversals",
                                authorizationId)
                                .header("Idempotency-Key", UUID.randomUUID().toString())
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(objectMapper.writeValueAsString(request))
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.authorizationId")
                        .value(authorizationId.toString()))
                .andExpect(jsonPath("$.operationId")
                        .value(operationId))
                .andExpect(jsonPath("$.status")
                        .value("REVERTIDA"));
    }
}
