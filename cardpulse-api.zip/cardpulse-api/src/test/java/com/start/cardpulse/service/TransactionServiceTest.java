package com.start.cardpulse.service;

import com.start.cardpulse.adapters.outbound.entities.Idempotency;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.repository.IdempotencyRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.mapper.IdempotencyMapper;
import com.start.cardpulse.application.mapper.TransactionMapper;
import com.start.cardpulse.application.service.TransactionService;
import com.start.cardpulse.application.usecases.DecideCancelAuthorizationUseCase;
import com.start.cardpulse.application.usecases.DecideCreditAuthorizationUseCase;
import com.start.cardpulse.application.usecases.DecideDebitAuthorizationUseCase;
import com.start.cardpulse.application.usecases.DecideReverseAuthorizationUseCase;
import com.start.cardpulse.domain.dto.transaction.TransactionRequest;
import com.start.cardpulse.domain.dto.transaction.TransactionResponse;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.CurrencyUsed;
import com.start.cardpulse.domain.enums.ReasonCode;
import com.start.cardpulse.domain.enums.TransactionType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

    @Mock
    private IdempotencyRepository idempotencyRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private DecideDebitAuthorizationUseCase decideDebitAuthorizationUseCase;

    @InjectMocks
    private TransactionService transactionService;

    private TransactionRequest debitRequest;

    private TransactionRequest creditRequest;

    @Mock
    private DecideCreditAuthorizationUseCase decideCreditAuthorizationUseCase;

    @Mock
    private DecideCancelAuthorizationUseCase decideCancelAuthorizationUseCase;

    @Mock
    private DecideReverseAuthorizationUseCase decideReverseAuthorizationUseCase;

    @Spy
    private IdempotencyMapper idempotencyMapper;

    @Spy
    private TransactionMapper transactionMapper;

    @BeforeEach
    void setUp() {

        debitRequest = new TransactionRequest(
                "origin-123",
                "card-token-123",
                TransactionType.DEBITO,
                new BigDecimal("100.00"),
                "BRL",
                "merchant-123",
                "2026-09-11T10:00:00Z"
        );

        creditRequest = new TransactionRequest(
                "TXN-001",
                "CARD_123456",
                TransactionType.CREDITO,
                new BigDecimal("500000"),
                "BRL",
                "LOJA-001",
                "2026-09-18T15:00:00Z"
        );
    }

    @Test
    void shouldReturnCachedResponseWhenIdempotencyKeyExistsAndIsNotExpired() {

        Instant now = Instant.now();

        UUID authorizationId = UUID.randomUUID();

        Idempotency idempotencyRecord = new Idempotency();
        idempotencyRecord.setAuthorizationId(authorizationId);
        idempotencyRecord.setStatus(AuthorizationStatus.APROVADA);
        idempotencyRecord.setReasonCode(ReasonCode.DEBIT_APPROVED);
        idempotencyRecord.setReason("Transação aprovada");
        idempotencyRecord.setType(TransactionType.DEBITO);
        idempotencyRecord.setReceivedAt(now);
        idempotencyRecord.setDecidedAt(now);
        idempotencyRecord.setCorrelationId("correlation-id");
        idempotencyRecord.setExpiresAt(now.plusSeconds(600));

        when(idempotencyRepository.findByIdempotencyKey("idem-key"))
                .thenReturn(Optional.of(idempotencyRecord));

        TransactionResponse result =
                transactionService.process(
                        "idem-key",
                        "correlation-id",
                        debitRequest
                );

        assertTrue(result.idempotentReplay());

        assertEquals(
                authorizationId,
                result.authorizationId()
        );

        assertEquals(
                AuthorizationStatus.APROVADA,
                result.status()
        );

        verifyNoInteractions(transactionRepository);
        verifyNoInteractions(decideDebitAuthorizationUseCase);
    }


    @Test
    void shouldReturnCachedResponseWhenIdempotencyKeyExistsAndIsNotExpiredInCredit() {

        Instant now = Instant.now();

        UUID authorizationId = UUID.randomUUID();

        Idempotency idempotencyRecord = new Idempotency();
        idempotencyRecord.setAuthorizationId(authorizationId);
        idempotencyRecord.setStatus(AuthorizationStatus.APROVADA);
        idempotencyRecord.setReasonCode(ReasonCode.CREDIT_APPROVED);
        idempotencyRecord.setReason("Transação aprovada");
        idempotencyRecord.setType(TransactionType.CREDITO);
        idempotencyRecord.setReceivedAt(now);
        idempotencyRecord.setDecidedAt(now);
        idempotencyRecord.setCorrelationId("correlation-id");
        idempotencyRecord.setExpiresAt(now.plusSeconds(600));

        when(idempotencyRepository.findByIdempotencyKey("idem-key"))
                .thenReturn(Optional.of(idempotencyRecord));

        TransactionResponse result =
                transactionService.process(
                        "idem-key",
                        "correlation-id",
                        debitRequest
                );

        assertTrue(result.idempotentReplay());

        assertEquals(
                authorizationId,
                result.authorizationId()
        );

        assertEquals(
                AuthorizationStatus.APROVADA,
                result.status()
        );

        verifyNoInteractions(transactionRepository);
        verifyNoInteractions(decideCreditAuthorizationUseCase);
    }


    @Test
    void shouldDeleteExpiredIdempotencyBeforeProcessingDebit() {

        Idempotency expiredRecord = new Idempotency();
        expiredRecord.setExpiresAt(
                Instant.now().minusSeconds(60)
        );

        TransactionResponse debitResponse =
                new TransactionResponse(
                        UUID.randomUUID(),
                        AuthorizationStatus.APROVADA,
                        ReasonCode.DEBIT_APPROVED,
                        "Transação aprovada",
                        TransactionType.DEBITO,
                        Instant.now(),
                        Instant.now(),
                        "correlation-id",
                        false
                );

        when(idempotencyRepository.findByIdempotencyKey("idem-key"))
                .thenReturn(Optional.of(expiredRecord));

        when(decideDebitAuthorizationUseCase.execute(any(UUID.class)))
                .thenReturn(debitResponse);

        transactionService.process(
                "idem-key",
                "correlation-id",
                debitRequest
        );

        verify(idempotencyRepository)
                .delete(expiredRecord);
    }

    @Test
    void shouldSaveTransactionAndCallDebitDecisionUseCase() {

        TransactionResponse expectedResponse =
                new TransactionResponse(
                        UUID.randomUUID(),
                        AuthorizationStatus.APROVADA,
                        ReasonCode.DEBIT_APPROVED,
                        "Transação aprovada",
                        TransactionType.DEBITO,
                        Instant.now(),
                        Instant.now(),
                        "correlation-id",
                        false
                );

        when(idempotencyRepository.findByIdempotencyKey(anyString()))
                .thenReturn(Optional.empty());

        when(decideDebitAuthorizationUseCase.execute(any(UUID.class)))
                .thenReturn(expectedResponse);

        TransactionResponse result =
                transactionService.process(
                        "idem-key",
                        "correlation-id",
                        debitRequest
                );

        assertEquals(expectedResponse, result);

        verify(transactionRepository)
                .save(any(Transaction.class));

        verify(decideDebitAuthorizationUseCase)
                .execute(any(UUID.class));
    }

    @Test
    void shouldPopulateTransactionFieldsCorrectly() {

        TransactionResponse debitResponse =
                new TransactionResponse(
                        UUID.randomUUID(),
                        AuthorizationStatus.APROVADA,
                        ReasonCode.DEBIT_APPROVED,
                        "Transação aprovada",
                        TransactionType.DEBITO,
                        Instant.now(),
                        Instant.now(),
                        "correlation-id",
                        false
                );

        when(idempotencyRepository.findByIdempotencyKey(anyString()))
                .thenReturn(Optional.empty());

        when(decideDebitAuthorizationUseCase.execute(any(UUID.class)))
                .thenReturn(debitResponse);

        transactionService.process(
                "idem-key",
                "correlation-id",
                debitRequest
        );

        ArgumentCaptor<Transaction> transactionCaptor =
                ArgumentCaptor.forClass(Transaction.class);

        verify(transactionRepository)
                .save(transactionCaptor.capture());

        Transaction savedTransaction =
                transactionCaptor.getValue();

        assertEquals(
                "idem-key",
                savedTransaction.getIdempotencyKey()
        );

        assertEquals(
                "card-token-123",
                savedTransaction.getCardToken()
        );

        assertEquals(
                TransactionType.DEBITO,
                savedTransaction.getTransactionType()
        );

        assertEquals(
                new BigDecimal("100.00"),
                savedTransaction.getAmount()
        );

        assertEquals(
                "merchant-123",
                savedTransaction.getMerchantId()
        );

        assertEquals(
                "BRL",
                savedTransaction.getCurrency()
        );

        assertEquals(
                AuthorizationStatus.RECEBIDA,
                savedTransaction.getStatus()
        );

        assertEquals(
                "correlation-id",
                savedTransaction.getCorrelationId()
        );

        assertEquals(
                Instant.parse("2026-09-11T10:00:00Z"),
                savedTransaction.getOccurredAt()
        );

        assertNotNull(savedTransaction.getCreatedAt());

        assertNotNull(savedTransaction.getReceivedAt());

        assertNotNull(savedTransaction.getId());

        assertEquals(
                savedTransaction.getId().toString(),
                savedTransaction.getOriginTransactionId()
        );
    }

    @Test
    void shouldSaveIdempotencyEntityAfterDebitProcessing() {

        UUID authorizationId = UUID.randomUUID();

        Instant receivedAt = Instant.now();
        Instant decidedAt = Instant.now();

        TransactionResponse debitResponse =
                new TransactionResponse(
                        authorizationId,
                        AuthorizationStatus.APROVADA,
                        ReasonCode.DEBIT_APPROVED,
                        "Transação aprovada",
                        TransactionType.DEBITO,
                        receivedAt,
                        decidedAt,
                        "correlation-id",
                        false
                );

        Transaction transaction = new Transaction();
        transaction.setId(UUID.randomUUID());

        when(idempotencyRepository.findByIdempotencyKey(anyString()))
                .thenReturn(Optional.empty());

        when(decideDebitAuthorizationUseCase.execute(any(UUID.class)))
                .thenReturn(debitResponse);

        doReturn(transaction)
                .when(transactionMapper)
                .fromTransaction(
                        any(UUID.class),
                        anyString(),
                        anyString(),
                        any(TransactionRequest.class)
                );

        transactionService.process(
                "idem-key",
                "correlation-id",
                debitRequest
        );

        ArgumentCaptor<Idempotency> captor =
                ArgumentCaptor.forClass(Idempotency.class);

        verify(idempotencyRepository)
                .save(captor.capture());

        Idempotency savedIdempotency = captor.getValue();

        assertEquals(
                "idem-key",
                savedIdempotency.getIdempotencyKey()
        );

        assertEquals(
                authorizationId,
                savedIdempotency.getAuthorizationId()
        );

        assertEquals(
                AuthorizationStatus.APROVADA,
                savedIdempotency.getStatus()
        );

        assertEquals(
                ReasonCode.DEBIT_APPROVED,
                savedIdempotency.getReasonCode()
        );

        assertEquals(
                "Transação aprovada",
                savedIdempotency.getReason()
        );

        assertEquals(
                TransactionType.DEBITO,
                savedIdempotency.getType()
        );

        assertEquals(
                CurrencyUsed.BRL,
                savedIdempotency.getCurrencyUsed()
        );

        assertEquals(
                new BigDecimal("100.00"),
                savedIdempotency.getValor()
        );

        assertEquals(
                "merchant-123",
                savedIdempotency.getDestination()
        );

        assertEquals(
                "correlation-id",
                savedIdempotency.getCorrelationId()
        );

        assertEquals(
                Instant.parse("2026-09-11T10:00:00Z"),
                savedIdempotency.getHora()
        );

        assertNotNull(savedIdempotency.getExpiresAt());

        verify(idempotencyMapper)
                .fromTransaction(
                        anyString(),
                        any(TransactionRequest.class),
                        any(TransactionResponse.class)
                );
    }

    @Test
    void shouldExecuteAndDelegateToProcess() {

        TransactionResponse expectedResponse =
                new TransactionResponse(
                        UUID.randomUUID(),
                        AuthorizationStatus.APROVADA,
                        ReasonCode.DEBIT_APPROVED,
                        "Transação aprovada",
                        TransactionType.DEBITO,
                        Instant.now(),
                        Instant.now(),
                        "correlation-id",
                        false
                );

        when(idempotencyRepository.findByIdempotencyKey(anyString()))
                .thenReturn(Optional.empty());

        when(decideDebitAuthorizationUseCase.execute(any(UUID.class)))
                .thenReturn(expectedResponse);

        TransactionResponse result =
                transactionService.execute(
                        debitRequest,
                        "idem-key",
                        "correlation-id"
                );

        assertEquals(
                expectedResponse,
                result
        );
    }

    @Test
    void shouldExecuteCancelAuthorizationUseCase() {

        UUID authorizationId = UUID.randomUUID();

        TransactionReleaseRequest request =
                new TransactionReleaseRequest(
                        "operation-id",
                        "Cancelamento solicitado"
                );

        Transaction transaction = new Transaction();
        transaction.setId(authorizationId);

        TransactionReleaseResponse expectedResponse =
                new TransactionReleaseResponse(
                        authorizationId,
                        "operation-id",
                        AuthorizationStatus.CANCELADA,
                        ReasonCode.CANCELLATION_APPROVED,
                        "Cancelamento aprovado",
                        new BigDecimal("100.00"),
                        Instant.now().toString(),
                        "correlation-id",
                        false
                );

        when(idempotencyRepository.findByIdempotencyKey(anyString()))
                .thenReturn(Optional.empty());

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(decideCancelAuthorizationUseCase.execute(
                authorizationId,
                request
        )).thenReturn(expectedResponse);

        TransactionReleaseResponse result =
                transactionService.cancel(
                        authorizationId,
                        "idem-key",
                        request
                );

        assertEquals(expectedResponse, result);

        verify(decideCancelAuthorizationUseCase)
                .execute(authorizationId, request);
    }

    @Test
    void shouldExecuteReverseAuthorizationUseCase() {

        UUID authorizationId = UUID.randomUUID();

        TransactionReleaseRequest request =
                new TransactionReleaseRequest(
                        "operation-id",
                        "Reversão solicitada"
                );

        Transaction transaction = new Transaction();
        transaction.setId(authorizationId);

        TransactionReleaseResponse expectedResponse =
                new TransactionReleaseResponse(
                        authorizationId,
                        "operation-id",
                        AuthorizationStatus.REVERTIDA,
                        ReasonCode.REVERSION_APPROVED,
                        "Reversão aprovada",
                        new BigDecimal("100.00"),
                        Instant.now().toString(),
                        "correlation-id",
                        false
                );

        when(idempotencyRepository.findByIdempotencyKey(anyString()))
                .thenReturn(Optional.empty());

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(decideReverseAuthorizationUseCase.execute(
                authorizationId,
                request
        )).thenReturn(expectedResponse);

        TransactionReleaseResponse result =
                transactionService.reverse(
                        authorizationId,
                        "idem-key",
                        request
                );

        assertEquals(expectedResponse, result);

        verify(decideReverseAuthorizationUseCase)
                .execute(authorizationId, request);
    }


}