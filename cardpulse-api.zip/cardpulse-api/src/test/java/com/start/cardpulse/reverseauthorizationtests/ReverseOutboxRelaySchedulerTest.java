package com.start.cardpulse.reverseauthorizationtests;


import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.kafka.publisher.CancelAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.CreditAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.DebitAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.ReverseAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.scheduler.OutboxRelayScheduler;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.domain.enums.OutboxEventStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReverseOutboxRelaySchedulerTest {


    @Mock
    private OutboxEventRepository repository;

    @Mock
    private CreditAuthorizationDecidedPublisher creditPublisher;

    @Mock
    private DebitAuthorizationDecidedPublisher debitPublisher;

    @Mock
    private CancelAuthorizationDecidedPublisher cancelPublisher;

    @Mock
    private ReverseAuthorizationDecidedPublisher reversePublisher;

    private OutboxRelayScheduler scheduler;

    @BeforeEach
    void setup() {

        scheduler = new OutboxRelayScheduler(
                repository,
                creditPublisher,
                debitPublisher,
                cancelPublisher,
                reversePublisher
        );
    }

    @Test
    void shouldPublishPendingEvent() {

        OutboxEvent event =
                new OutboxEvent(
                        UUID.randomUUID(),
                        "ReverseAuthorizationDecided",
                        "{\"status\":\"APROVADA\"}"
                );

        when(repository.findByStatus(
                OutboxEventStatus.PENDENTE))
                .thenReturn(List.of(event));

        when(reversePublisher.publish(any(), any()))
                .thenReturn(
                        CompletableFuture.completedFuture(null)
                );

        scheduler.relay();

        verify(reversePublisher).publish(
                eq(event.getTransactionId().toString()),
                eq(event.getPayload())
        );

        verify(repository).save(event);

        assertEquals(
                OutboxEventStatus.PUBLICADO,
                event.getStatus()
        );

        assertEquals(
                0,
                event.getRetryCount()
        );
    }

    @Test
    void shouldIncrementRetryWhenPublishFails() {

        OutboxEvent event =
                new OutboxEvent(
                        UUID.randomUUID(),
                        "ReverseAuthorizationDecided",
                        "{\"status\":\"APROVADA\"}"
                );

        when(repository.findByStatus(
                OutboxEventStatus.PENDENTE))
                .thenReturn(List.of(event));

        CompletableFuture<Void> future =
                CompletableFuture.failedFuture(
                        new RuntimeException("Kafka indisponível")
                );

        when(reversePublisher.publish(any(), any()))
                .thenReturn(future);

        scheduler.relay();

        verify(repository).save(event);

        assertEquals(
                OutboxEventStatus.PENDENTE,
                event.getStatus()
        );

        assertEquals(
                1,
                event.getRetryCount()
        );
    }
}
