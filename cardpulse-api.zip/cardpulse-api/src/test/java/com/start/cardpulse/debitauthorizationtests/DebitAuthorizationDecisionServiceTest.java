package com.start.cardpulse.debitauthorizationtests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.repository.AccountRepository;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.ports.out.AuthorizationAuditPort;
import com.start.cardpulse.application.service.DebitAuthorizationDecisionService;
import com.start.cardpulse.domain.dto.transaction.TransactionResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;
import com.start.cardpulse.domain.enums.TransactionType;
import com.start.cardpulse.domain.exception.AuthorizationAlreadyDecidedException;
import com.start.cardpulse.domain.exception.AuthorizationNotFoundException;
import com.start.cardpulse.domain.exception.OutboxEventCreationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DebitAuthorizationDecisionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private OutboxEventRepository outboxEventRepository;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private AuthorizationAuditPort auditPort;

    @InjectMocks
    private DebitAuthorizationDecisionService service;

    @Test
    void shouldApproveDebitWhenBalanceIsSufficient() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createReceivedDebitTransaction(
                        authorizationId
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(accountRepository.debitIfSufficientBalance(
                "card-123",
                BigDecimal.valueOf(100)))
                .thenReturn(1);

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"APROVADA\"}");

        TransactionResponse response =
                service.execute(authorizationId);

        Assertions.assertEquals(
                AuthorizationStatus.APROVADA,
                response.status());

        Assertions.assertEquals(
                ReasonCode.DEBIT_APPROVED,
                response.reasonCode());

        Assertions.assertFalse(response.idempotentReplay());

        verify(accountRepository)
                .debitIfSufficientBalance(
                        "card-123",
                        BigDecimal.valueOf(100));

        verify(auditPort).save(any());
        verify(outboxEventRepository)
                .save(any(OutboxEvent.class));

    }

    @Test
    void shouldDenyDebitWhenBalanceIsInsufficient() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createReceivedDebitTransaction(
                        authorizationId
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(accountRepository.debitIfSufficientBalance(
                "card-123",
                BigDecimal.valueOf(100)))
                .thenReturn(0);

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"NEGADA\"}");

        TransactionResponse response =
                service.execute(authorizationId);

        verify(accountRepository)
                .debitIfSufficientBalance(
                        "card-123",
                        BigDecimal.valueOf(100)
                );

        Assertions.assertEquals(
                AuthorizationStatus.NEGADA,
                response.status());

        Assertions.assertEquals(
                ReasonCode.INSUFFICIENT_BALANCE,
                response.reasonCode());
    }

    @Test
    void shouldThrowExceptionWhenAuthorizationNotFound() {

        UUID authorizationId = UUID.randomUUID();

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.empty());

        Assertions.assertThrows(
                AuthorizationNotFoundException.class,
                () -> service.execute(authorizationId)
        );
    }

    @Test
    void shouldThrowExceptionWhenAuthorizationAlreadyDecided() {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction = new Transaction();
        transaction.setStatus(AuthorizationStatus.APROVADA);

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        Assertions.assertThrows(
                AuthorizationAlreadyDecidedException.class,
                () -> service.execute(authorizationId)
        );

        verify(accountRepository, never())
                .debitIfSufficientBalance(any(), any());
    }

    @Test
    void shouldApproveWhenBalanceIsExactlyTheRequestedAmount() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createReceivedDebitTransaction(
                        authorizationId
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(accountRepository.debitIfSufficientBalance(
                any(),
                any()))
                .thenReturn(1);

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"APROVADA\"}");

        TransactionResponse response =
                service.execute(authorizationId);

        Assertions.assertEquals(
                AuthorizationStatus.APROVADA,
                response.status());
    }

    @Test
    void shouldThrowExceptionWhenOutboxEventCannotBeCreated() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createReceivedDebitTransaction(
                        authorizationId
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(accountRepository.debitIfSufficientBalance(
                any(),
                any()))
                .thenReturn(1);

        when(objectMapper.writeValueAsString(any()))
                .thenThrow(new RuntimeException());

        Assertions.assertThrows(
                OutboxEventCreationException.class,
                () -> service.execute(authorizationId)
        );
    }


    @Test
    void shouldApproveAuthorizationEvenWhenAuditFails() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createReceivedDebitTransaction(
                        authorizationId
                );

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(accountRepository.debitIfSufficientBalance(
                any(),
                any()))
                .thenReturn(1);

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{}");

        doThrow(new RuntimeException("Mongo down"))
                .when(auditPort)
                .save(any());

        TransactionResponse response =
                service.execute(authorizationId);

        verify(auditPort)
                .save(any());

        verify(outboxEventRepository)
                .save(any(OutboxEvent.class));

        Assertions.assertEquals(
                AuthorizationStatus.APROVADA,
                response.status()
        );
    }

    @Test
    void shouldAuditDeniedAuthorization() throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createReceivedDebitTransaction(authorizationId);

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(accountRepository.debitIfSufficientBalance(
                any(),
                any()))
                .thenReturn(0);

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"NEGADA\"}");

        service.execute(authorizationId);

        verify(auditPort).save(any());
    }

    @Test
    void shouldCreateOutboxEventWhenAuthorizationIsDenied()
            throws Exception {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                createReceivedDebitTransaction(authorizationId);

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        when(accountRepository.debitIfSufficientBalance(
                any(),
                any()))
                .thenReturn(0);

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{\"status\":\"NEGADA\"}");

        service.execute(authorizationId);

        verify(outboxEventRepository)
                .save(any(OutboxEvent.class));
    }

    @Test
    void shouldNotAuditWhenAuthorizationIsAlreadyDecided() {

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction = new Transaction();
        transaction.setStatus(AuthorizationStatus.APROVADA);

        when(transactionRepository.findById(authorizationId))
                .thenReturn(Optional.of(transaction));

        Assertions.assertThrows(
                AuthorizationAlreadyDecidedException.class,
                () -> service.execute(authorizationId)
        );

        verifyNoInteractions(auditPort);
    }


    private Transaction createReceivedDebitTransaction(UUID authorizationId) {

        Transaction transaction = new Transaction();
        transaction.setId(authorizationId);
        transaction.setStatus(AuthorizationStatus.RECEBIDA);
        transaction.setTransactionType(TransactionType.DEBITO);
        transaction.setCardToken("card-123");
        transaction.setAmount(BigDecimal.valueOf(100));

        return transaction;
    }
}
