package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.dto.authorizationdetails.AuthorizationDetailsResponse;

import java.util.UUID;

public interface GetAuthorizationDetailsUseCase {
    AuthorizationDetailsResponse execute(
            UUID authorizationId
    );
}
