package com.start.cardpulse.adapters.outbound.repository;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface CaptureAuthorizationRepository extends JpaRepository<Transaction, UUID> {

    Optional<Transaction> findById(UUID authorizationId);

    @Modifying
    @Query("""
            
            UPDATE Transaction t
            
            SET t.status = :newStatus
            
            
            
            WHERE t.id = :authorizationId
            
            AND t.status = :currentStatus
            
            """)
    int changeStatus(

            UUID authorizationId,

            AuthorizationStatus currentStatus,

            AuthorizationStatus newStatus


    );
}
