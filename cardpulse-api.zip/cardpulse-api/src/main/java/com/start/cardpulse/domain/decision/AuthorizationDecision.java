package com.start.cardpulse.domain.decision;

import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;
import com.start.cardpulse.domain.exception.ValidationMessages;

import java.time.Instant;

public record AuthorizationDecision(AuthorizationStatus status, ReasonCode reasonCode, String reason,
                                    Instant decidedAt) {

    public static AuthorizationDecision creditApproved() {
        return new AuthorizationDecision(
                AuthorizationStatus.APROVADA,
                ReasonCode.CREDIT_APPROVED,
                ValidationMessages.CREDIT_APPROVED,
                Instant.now()
        );
    }

    public static AuthorizationDecision creditInsufficientLimit() {
        return new AuthorizationDecision(
                AuthorizationStatus.NEGADA,
                ReasonCode.INSUFFICIENT_CREDIT_LIMIT,
                ValidationMessages.INSUFFICIENT_CREDIT_LIMIT,
                Instant.now()
        );
    }


    public static AuthorizationDecision approvedDebit() {
        return new AuthorizationDecision(
                AuthorizationStatus.APROVADA,
                ReasonCode.DEBIT_APPROVED,
                ValidationMessages.APPROVED_TRANSACTION,
                Instant.now()
        );
    }

    public static AuthorizationDecision insufficientBalance() {
        return new AuthorizationDecision(
                AuthorizationStatus.NEGADA,
                ReasonCode.INSUFFICIENT_BALANCE,
                ValidationMessages.INSUFFICIENT_BALANCE,
                Instant.now()
        );
    }

    public static AuthorizationDecision approvedCancellation() {
        return new AuthorizationDecision(
                AuthorizationStatus.CANCELADA,
                ReasonCode.CANCELLATION_APPROVED,
                ValidationMessages.APPROVED_CANCELLATION,
                Instant.now()
        );
    }

    public static AuthorizationDecision approvedReversion() {
        return new AuthorizationDecision(
                AuthorizationStatus.REVERTIDA,
                ReasonCode.REVERSION_APPROVED,
                ValidationMessages.APPROVED_REVERSION,
                Instant.now()
        );
    }


}
