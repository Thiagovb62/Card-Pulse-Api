package com.start.cardpulse.adapters.inbound.controller;


import com.start.cardpulse.application.usecases.GetPendingIntegrationsUseCase;
import com.start.cardpulse.application.usecases.ReprocessPendingIntegrationUseCae;
import com.start.cardpulse.common.HeaderConstants;
import com.start.cardpulse.domain.dto.operations.PendingIntegrationResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/api/v1/operations")
@Tag(name = "Reprocess")
public class OperationsController {

    private final ReprocessPendingIntegrationUseCae reprocessUseCase;
    private final GetPendingIntegrationsUseCase getPendingIntegrationsUseCase;

    public OperationsController(ReprocessPendingIntegrationUseCae reprocessUseCase, GetPendingIntegrationsUseCase getPendingIntegrationsUseCase
    ) {
        this.reprocessUseCase = reprocessUseCase;
        this.getPendingIntegrationsUseCase = getPendingIntegrationsUseCase;
    }


    @GetMapping("/pending-integrations")
    public ResponseEntity<List<PendingIntegrationResponse>> getPendingIntegrations() {

        return ResponseEntity.ok(getPendingIntegrationsUseCase.execute()
        );
    }

    @PostMapping("/pending-integrations/{pendingId}/reprocess")
    public ResponseEntity<Void> reprocess(

            @PathVariable UUID pendingId,
            @RequestHeader(
                    value = HeaderConstants.CORRELATION_ID,
                    required = false
            )
            String correlationId
    ) {

        if (correlationId == null) correlationId = UUID.randomUUID().toString();


        reprocessUseCase.execute(
                pendingId,
                "OPERATOR",
                correlationId);

        return ok().build();

    }


}
