package com.start.cardpulse.domain.enums;

import java.util.Arrays;

public enum EventType {

    AUTHORIZATION_CAPTURED("AuthorizationCaptured"),
    CREDIT_AUTHORIZATION_DECIDED("CreditAuthorizationDecided"),
    DEBIT_AUTHORIZATION_DECIDED("DebitAuthorizationDecided"),
    CANCEL_AUTHORIZATION_DECIDED("CancelAuthorizationDecided"),
    REVERSE_AUTHORIZATION_DECIDED("ReverseAuthorizationDecided"),
    UNSUPPORTED_EVENT_TYPE("Unsupported event type: ");


    private final String value;

    EventType(String value) {
        this.value = value;
    }

    private String getValue() {
        return value;
    }

    public static EventType fromValue(String value) {
        return Arrays.stream(values())
                .filter(eventType -> eventType.getValue().equals(value))
                .findFirst()
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                UNSUPPORTED_EVENT_TYPE + value));
    }


}
