package com.start.cardpulse.adapters.outbound.kafka.scheduler;

import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.kafka.publisher.CancelAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.CaptureAuthorizationsPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.CreditAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.DebitAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.ReverseAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.domain.enums.EventType;
import com.start.cardpulse.domain.enums.OutboxEventStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class OutboxRelayScheduler {

    private final OutboxEventRepository repository;
    private final CreditAuthorizationDecidedPublisher creditPublisher;
    private final DebitAuthorizationDecidedPublisher debitPublisher;
    private final CaptureAuthorizationsPublisher captureAuthorizationsPublisher;
    private final CancelAuthorizationDecidedPublisher cancelPublisher;
    private final ReverseAuthorizationDecidedPublisher reversePublisher;

    public OutboxRelayScheduler(
            OutboxEventRepository repository,
            CreditAuthorizationDecidedPublisher creditPublisher,
            DebitAuthorizationDecidedPublisher debitPublisher,
            CaptureAuthorizationsPublisher captureAuthorizationsPublisher,
            CancelAuthorizationDecidedPublisher cancelPublisher,
            ReverseAuthorizationDecidedPublisher reversePublisher) {

        this.repository = repository;
        this.creditPublisher = creditPublisher;
        this.debitPublisher = debitPublisher;
        this.captureAuthorizationsPublisher = captureAuthorizationsPublisher;
        this.cancelPublisher = cancelPublisher;
        this.reversePublisher = reversePublisher;
    }

    @Scheduled(fixedDelay = 5000)
    public void relay() {

        var pendents = repository.findByStatus(
                OutboxEventStatus.PENDENTE
        );

        for (OutboxEvent event : pendents) {

            try {

                switch (EventType.fromValue(event.getEventType())) {

                    case CREDIT_AUTHORIZATION_DECIDED -> creditPublisher.publish(
                            event.getTransactionId().toString(),
                            event.getPayload()
                    ).get();

                    case DEBIT_AUTHORIZATION_DECIDED -> debitPublisher.publish(
                            event.getTransactionId().toString(),
                            event.getPayload()
                    ).get();

                    case AUTHORIZATION_CAPTURED -> captureAuthorizationsPublisher.publish(
                            event.getTransactionId().toString(),
                            event.getPayload()
                    ).get();

                    case CANCEL_AUTHORIZATION_DECIDED -> cancelPublisher.publish(
                            event.getTransactionId().toString(),
                            event.getPayload()
                    ).get();


                    case REVERSE_AUTHORIZATION_DECIDED -> reversePublisher.publish(
                            event.getTransactionId().toString(),
                            event.getPayload()
                    ).get();
                }

                event.markAsPublished();
                repository.save(event);

            } catch (Exception ex) {

                event.incrementRetry();
                repository.save(event);
            }
        }
    }
}
