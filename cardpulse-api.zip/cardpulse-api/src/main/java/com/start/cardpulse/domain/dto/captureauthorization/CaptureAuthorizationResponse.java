package com.start.cardpulse.domain.dto.captureauthorization;

import com.start.cardpulse.domain.enums.AuthorizationStatus;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

public record CaptureAuthorizationResponse(
        UUID authorizationId,
        String captureId,
        AuthorizationStatus status,
        BigDecimal capturedAmount,
        String currency,
        OffsetDateTime capturedAt,
        String correlationId,
        Boolean idempotentReplay
) {
}
