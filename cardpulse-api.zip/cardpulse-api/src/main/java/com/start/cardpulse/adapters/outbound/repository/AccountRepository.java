package com.start.cardpulse.adapters.outbound.repository;

import com.start.cardpulse.adapters.outbound.entities.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.UUID;


@Repository
public interface AccountRepository extends JpaRepository<Account, UUID> {

    @Modifying
    @Query("""
            UPDATE Account a
            SET a.balance = a.balance - :amount
            WHERE a.cardToken = :cardToken
            AND a.balance >= :amount
            """)
    int debitIfSufficientBalance(
            @Param("cardToken") String cardToken,
            @Param("amount") BigDecimal amount
    );

    @Modifying
    @Query("""
             UPDATE Account a
             SET a.availableCreditLimit =
                 a.availableCreditLimit - :amount
             WHERE a.cardToken = :cardToken
             AND a.availableCreditLimit >= :amount
            """)
    int consumeCreditLimit(
            @Param("cardToken") String cardToken,
            @Param("amount") BigDecimal amount
    );


    @Modifying
    @Query("""
            UPDATE Account a
            SET a.balance = a.balance + :amount
            WHERE a.cardToken = :cardToken
            """)
    void restoreBalance(
            @Param("cardToken") String cardToken,
            @Param("amount") BigDecimal amount
    );

    @Modifying
    @Query("""
            UPDATE Account a
            SET a.availableCreditLimit =
                a.availableCreditLimit + :amount
            WHERE a.cardToken = :cardToken
            """)
    void restoreCreditLimit(
            @Param("cardToken") String cardToken,
            @Param("amount") BigDecimal amount
    );

}
