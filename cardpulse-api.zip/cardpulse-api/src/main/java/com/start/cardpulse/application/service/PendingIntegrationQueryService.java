package com.start.cardpulse.application.service;

import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.application.usecases.GetPendingIntegrationsUseCase;
import com.start.cardpulse.domain.dto.operations.PendingIntegrationResponse;
import com.start.cardpulse.domain.enums.OutboxEventStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PendingIntegrationQueryService
        implements GetPendingIntegrationsUseCase {

    private final OutboxEventRepository outboxEventRepository;

    public PendingIntegrationQueryService(
            OutboxEventRepository outboxEventRepository
    ) {
        this.outboxEventRepository = outboxEventRepository;
    }

    @Override
    public List<PendingIntegrationResponse> execute() {

        List<PendingIntegrationResponse> response =
                new ArrayList<>();

        List<OutboxEvent> pendingEvents =
                outboxEventRepository.findByStatus(
                        OutboxEventStatus.PENDENTE
                );

        for (OutboxEvent event : pendingEvents) {

            response.add(
                    new PendingIntegrationResponse(
                            event.getId(),
                            event.getTransactionId(),
                            event.getEventType(),
                            event.getStatus(),
                            event.getRetryCount(),
                            event.getCreatedAt(),
                            event.getPublishedAt()
                    )
            );
        }

        return response;
    }
}
