package com.start.cardpulse.domain.exception;

public class CreditLimitNotFoundException extends RuntimeException {
    public CreditLimitNotFoundException() {
        super("Credit limit not found");
    }
}
