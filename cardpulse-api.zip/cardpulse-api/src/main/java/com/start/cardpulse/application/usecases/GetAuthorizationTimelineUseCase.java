package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.dto.timeline.AuthorizationTimelineResponse;

import java.util.UUID;

public interface GetAuthorizationTimelineUseCase {
    AuthorizationTimelineResponse execute(
            UUID authorizationId
    );
}
