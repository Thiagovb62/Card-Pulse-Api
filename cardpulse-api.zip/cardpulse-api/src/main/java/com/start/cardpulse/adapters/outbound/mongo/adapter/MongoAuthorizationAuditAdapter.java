package com.start.cardpulse.adapters.outbound.mongo.adapter;

import com.start.cardpulse.adapters.outbound.mongo.document.AuthorizationAuditDocument;
import com.start.cardpulse.adapters.outbound.mongo.repository.AuthorizationAuditRepository;
import com.start.cardpulse.application.ports.out.AuthorizationAuditPort;
import org.springframework.stereotype.Component;

@Component
public class MongoAuthorizationAuditAdapter
        implements AuthorizationAuditPort {

    private final AuthorizationAuditRepository repository;

    public MongoAuthorizationAuditAdapter(
            AuthorizationAuditRepository repository) {
        this.repository = repository;
    }

    @Override
    public void save(AuthorizationAuditDocument audit) {
        repository.save(audit);
    }
}
