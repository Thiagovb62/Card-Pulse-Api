package com.start.cardpulse.application.mapper;

import com.start.cardpulse.adapters.outbound.entities.Idempotency;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.domain.dto.transaction.TransactionRequest;
import com.start.cardpulse.domain.dto.transaction.TransactionResponse;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.CurrencyUsed;
import com.start.cardpulse.domain.enums.ReasonCode;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

@Component
public class IdempotencyMapper {

    private static final Duration TTL = Duration.ofMinutes(10);

    public Idempotency fromTransaction(
            String idempotencyKey,
            TransactionRequest request,
            TransactionResponse response) {

        Idempotency entity = createBase(
                idempotencyKey,
                response.authorizationId(),
                response.status(),
                response.reasonCode(),
                response.reason(),
                response.correlationId(),
                response.receivedAt(),
                response.decidedAt()
        );

        entity.setValor(request.getAmount());
        entity.setCurrencyUsed(CurrencyUsed.BRL);
        entity.setType(request.getTransactionType());
        entity.setDestination(request.getMerchantId());
        entity.setUsuarioId(1L);

        entity.setHora(
                Instant.parse(request.getOccurredAt())
        );

        entity.setReceivedAt(
                response.receivedAt()
        );

        entity.setDecidedAt(
                response.decidedAt()
        );

        return entity;
    }


    public Idempotency fromRelease(
            String idempotencyKey,
            TransactionReleaseRequest request,
            Transaction transaction,
            TransactionReleaseResponse response) {

        Idempotency entity = createBase(
                idempotencyKey,
                response.authorizationId(),
                response.status(),
                response.reasonCode(),
                response.reason(),
                response.correlationId(),
                transaction.getReceivedAt(),
                Instant.parse(response.occurredAt())
        );

        entity.setValor(
                response.reversedAmount()
        );

        entity.setCurrencyUsed(
                CurrencyUsed.BRL
        );

        entity.setOperationId(
                request.getOriginOperationId()
        );


        entity.setUsuarioId(1L);

        entity.setDestination(
                transaction.getMerchantId()
        );

        entity.setType(
                transaction.getTransactionType()
        );

        entity.setHora(
                transaction.getOccurredAt()
        );

        entity.setReceivedAt(
                transaction.getReceivedAt()
        );

        entity.setDecidedAt(
                Instant.parse(response.occurredAt())
        );

        return entity;
    }

    private Idempotency createBase(
            String idempotencyKey,
            UUID authorizationId,
            AuthorizationStatus status,
            ReasonCode reasonCode,
            String reason,
            String correlationId,
            Instant receivedAt,
            Instant decidedAt) {

        Idempotency entity = new Idempotency();

        entity.setIdempotencyKey(idempotencyKey);
        entity.setAuthorizationId(authorizationId);

        entity.setStatus(status);
        entity.setReasonCode(reasonCode);
        entity.setReason(reason);

        entity.setCorrelationId(correlationId);

        entity.setReceivedAt(receivedAt);
        entity.setDecidedAt(decidedAt);

        entity.setExpiresAt(
                Instant.now().plus(TTL)
        );

        return entity;
    }
}
