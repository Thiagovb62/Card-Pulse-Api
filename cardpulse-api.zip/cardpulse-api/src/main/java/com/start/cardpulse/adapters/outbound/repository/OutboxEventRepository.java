package com.start.cardpulse.adapters.outbound.repository;

import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.domain.enums.OutboxEventStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface OutboxEventRepository extends JpaRepository<OutboxEvent, UUID> {
    List<OutboxEvent> findByStatus(OutboxEventStatus status);

    List<OutboxEvent> findByTransactionId(
            UUID transactionId
    );
}
