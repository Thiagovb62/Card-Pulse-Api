package com.start.cardpulse.application.service;

import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.mongo.document.AuthorizationAuditDocument;
import com.start.cardpulse.adapters.outbound.mongo.repository.AuthorizationAuditRepository;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.usecases.GetAuthorizationTimelineUseCase;
import com.start.cardpulse.domain.dto.timeline.AuthorizationTimelineResponse;
import com.start.cardpulse.domain.dto.timeline.TimelineEventResponse;
import com.start.cardpulse.domain.enums.OutboxEventStatus;
import com.start.cardpulse.domain.exception.AuthorizationNotFoundException;
import org.springframework.stereotype.Service;

import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

@Service
public class AuthorizationTimelineService
        implements GetAuthorizationTimelineUseCase {

    private final TransactionRepository transactionRepository;
    private final AuthorizationAuditRepository auditRepository;
    private final OutboxEventRepository outboxEventRepository;

    public AuthorizationTimelineService(
            TransactionRepository transactionRepository,
            AuthorizationAuditRepository auditRepository,
            OutboxEventRepository outboxEventRepository
    ) {
        this.transactionRepository = transactionRepository;
        this.auditRepository = auditRepository;
        this.outboxEventRepository = outboxEventRepository;
    }

    @Override
    public AuthorizationTimelineResponse execute(
            UUID authorizationId
    ) {

        Transaction transaction =
                transactionRepository.findById(
                        authorizationId
                ).orElseThrow(
                        AuthorizationNotFoundException::new
                );

        boolean partialInformation = false;

        List<TimelineEventResponse> timeline =
                new ArrayList<>();

        timeline.add(
                new TimelineEventResponse(
                        "AUTHORIZATION_RECEIVED",
                        transaction.getReceivedAt()
                )
        );

        if (transaction.getDecidedAt() != null) {

            timeline.add(
                    new TimelineEventResponse(
                            "AUTHORIZATION_DECIDED",
                            transaction.getDecidedAt()
                    )
            );
        }

        try {

            List<AuthorizationAuditDocument> audits =
                    auditRepository.findByAuthorizationId(
                            authorizationId
                    );

            audits.forEach(audit ->
                    timeline.add(
                            new TimelineEventResponse(
                                    audit.getOccurrenceType(),
                                    audit.getOccurredAt()
                            )
                    )
            );

        } catch (Exception ex) {
            partialInformation = true;
        }

        try {

            List<OutboxEvent> events =
                    outboxEventRepository.findByTransactionId(
                            authorizationId
                    );

            for (OutboxEvent event : events) {

                timeline.add(
                        new TimelineEventResponse(
                                "KAFKA_EVENT_CREATED",
                                event.getCreatedAt()
                                        .toInstant(ZoneOffset.UTC)
                        )
                );

                if (event.getStatus()
                        == OutboxEventStatus.PUBLICADO
                        && event.getPublishedAt() != null) {

                    timeline.add(
                            new TimelineEventResponse(
                                    "KAFKA_EVENT_PUBLISHED",
                                    event.getPublishedAt()
                                            .toInstant(
                                                    ZoneOffset.UTC
                                            )
                            )
                    );
                }
            }

        } catch (Exception ex) {
            partialInformation = true;
        }

        timeline.sort(
                Comparator.comparing(
                        TimelineEventResponse::timestamp
                )
        );

        return new AuthorizationTimelineResponse(
                authorizationId,
                partialInformation,
                timeline
        );
    }
}
