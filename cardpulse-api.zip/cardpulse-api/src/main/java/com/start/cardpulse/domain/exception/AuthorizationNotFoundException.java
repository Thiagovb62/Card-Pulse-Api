package com.start.cardpulse.domain.exception;

import org.springframework.http.HttpStatus;

public class AuthorizationNotFoundException extends BusinessException {

    public AuthorizationNotFoundException() {
        super("AUTHORIZATION_NOT_FOUND", ValidationMessages.AUTHORIZATION_NOT_FOUND, HttpStatus.NOT_FOUND);
    }
}