package com.start.cardpulse.domain.exception;

import org.springframework.http.HttpStatus;

public class AuthorizationAlreadyDecidedException extends BusinessException {

    public AuthorizationAlreadyDecidedException() {
        super("AUTHORIZATION_ALREADY_DECIDED", ValidationMessages.AUTHORIZATION_ALREADY_DECIDED, HttpStatus.BAD_REQUEST);
    }
}
