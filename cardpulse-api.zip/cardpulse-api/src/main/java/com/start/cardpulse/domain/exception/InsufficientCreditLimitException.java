package com.start.cardpulse.domain.exception;

public class InsufficientCreditLimitException extends RuntimeException {

    public InsufficientCreditLimitException() {
        super();
    }
}
