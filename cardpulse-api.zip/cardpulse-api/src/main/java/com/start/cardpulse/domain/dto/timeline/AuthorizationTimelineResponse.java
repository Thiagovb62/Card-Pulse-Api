package com.start.cardpulse.domain.dto.timeline;

import java.util.List;
import java.util.UUID;

public record AuthorizationTimelineResponse(
        UUID authorizationId,
        boolean partialInformation,
        List<TimelineEventResponse> events) {
}
