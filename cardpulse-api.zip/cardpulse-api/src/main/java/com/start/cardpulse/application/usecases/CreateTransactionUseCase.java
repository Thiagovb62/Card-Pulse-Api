package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.dto.transaction.TransactionRequest;
import com.start.cardpulse.domain.dto.transaction.TransactionResponse;

public interface CreateTransactionUseCase {
    TransactionResponse execute(
            TransactionRequest request,
            String idempotencyKey,
            String correlationId
    );
}
