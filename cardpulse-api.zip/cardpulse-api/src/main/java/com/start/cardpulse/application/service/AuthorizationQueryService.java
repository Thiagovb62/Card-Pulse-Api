package com.start.cardpulse.application.service;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.usecases.GetAuthorizationDetailsUseCase;
import com.start.cardpulse.domain.dto.authorizationdetails.AuthorizationDetailsResponse;
import com.start.cardpulse.domain.exception.AuthorizationNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;


@Service
public class AuthorizationQueryService  implements GetAuthorizationDetailsUseCase {

    private final TransactionRepository transactionRepository;

    public AuthorizationQueryService(
            TransactionRepository transactionRepository
    ) {
        this.transactionRepository = transactionRepository;
    }

    @Override
    public AuthorizationDetailsResponse execute(
            UUID authorizationId
    ) {

        Transaction transaction =
                transactionRepository.findById(
                        authorizationId
                ).orElseThrow(
                        AuthorizationNotFoundException::new
                );

        return new AuthorizationDetailsResponse(
                transaction.getId(),
                transaction.getOriginTransactionId(),
                transaction.getTransactionType(),
                transaction.getStatus(),
                transaction.getAmount(),
                transaction.getCurrency(),
                transaction.getReasonCode(),
                transaction.getOccurredAt(),
                transaction.getReceivedAt(),
                transaction.getDecidedAt(),
                List.of(transaction.getCorrelationId()),
                null,
                false
        );
    }
}
