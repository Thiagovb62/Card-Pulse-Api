package com.start.cardpulse.adapters.inbound.controller;

import com.start.cardpulse.application.service.CaptureAuthorizationService;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationRequest;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.UUID;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/authorizations/{authorizationId}/captures")
@Tag(name = "CaptureAuthorizations")
public class CaptureAuthorizationController {

    private final CaptureAuthorizationService captureAuthorizationService;

    @PostMapping()
    public ResponseEntity<CaptureAuthorizationResponse> capture(
            @PathVariable UUID authorizationId,
            @RequestBody CaptureAuthorizationRequest captureAuthorizationRequest,
            @RequestHeader("Idempotency-Key") String idempotencyKey,
            @RequestHeader("X-Correlation-ID") String correlationId
    ) {


        return ResponseEntity.ok(
                captureAuthorizationService.execute(
                        captureAuthorizationRequest,
                        idempotencyKey,
                        correlationId));
    }
}
