package com.start.cardpulse.adapters.outbound.mongo.repository;

import com.start.cardpulse.adapters.outbound.mongo.document.AuthorizationAuditDocument;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.UUID;

public interface AuthorizationAuditRepository extends MongoRepository<
        AuthorizationAuditDocument,
        String> {

      List<AuthorizationAuditDocument> findByAuthorizationId(
              UUID authorizationId
      );
}
