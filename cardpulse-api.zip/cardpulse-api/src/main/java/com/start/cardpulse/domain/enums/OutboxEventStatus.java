package com.start.cardpulse.domain.enums;

public enum OutboxEventStatus {
    PENDENTE,
    PUBLICADO
}
