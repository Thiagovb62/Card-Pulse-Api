package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationRequest;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationResponse;

public interface CaptureAuthorizationUseCase {

    CaptureAuthorizationResponse execute(
            CaptureAuthorizationRequest request,
            String idempotencyKey,
            String correlationId);
}
