package com.start.cardpulse.common;

public final class HeaderConstants {

    private HeaderConstants() {
    }

    public static final String CORRELATION_ID = "X-Correlation-ID";
    public static final String IDEMPOTENCY_KEY = "Idempotency-Key";
}
