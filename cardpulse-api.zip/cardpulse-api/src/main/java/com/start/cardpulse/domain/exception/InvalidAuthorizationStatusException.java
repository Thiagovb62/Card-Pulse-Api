package com.start.cardpulse.domain.exception;

import org.springframework.http.HttpStatus;

public class InvalidAuthorizationStatusException extends BusinessException {

    public InvalidAuthorizationStatusException(String message) {
        super("INVALID_AUTHORIZATIONS", message, HttpStatus.UNPROCESSABLE_CONTENT);
    }
}
