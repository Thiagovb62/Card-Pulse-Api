package com.start.cardpulse.adapters.outbound.kafka.publisher;

import com.start.cardpulse.application.ports.out.EventPublisherPort;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component
public class CaptureAuthorizationsPublisher implements EventPublisherPort {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final String topic;

    public CaptureAuthorizationsPublisher(
            KafkaTemplate<String, String> kafkaTemplate,
            @Value("${cardpulse.kafka.topics.authorization-captured}")
            String topic) {

        this.kafkaTemplate = kafkaTemplate;
        this.topic = topic;
    }


    @Override
    public CompletableFuture<Void> publish(
            String key,
            String payload) {

        return kafkaTemplate
                .send(topic, key, payload)
                .thenAccept(SendResult -> {
                });
    }
}
