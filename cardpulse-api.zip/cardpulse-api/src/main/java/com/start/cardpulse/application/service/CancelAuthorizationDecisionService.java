package com.start.cardpulse.application.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.mongo.document.AuthorizationAuditDocument;
import com.start.cardpulse.adapters.outbound.repository.AccountRepository;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.ports.out.AuthorizationAuditPort;
import com.start.cardpulse.application.usecases.DecideCancelAuthorizationUseCase;
import com.start.cardpulse.domain.decision.AuthorizationDecision;
import com.start.cardpulse.domain.decision.AuthorizationReleaseDecision;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.event.CancelAuthorizationDecidedEvent;
import com.start.cardpulse.domain.exception.AuthorizationNotApprovedException;
import com.start.cardpulse.domain.exception.AuthorizationNotFoundException;
import com.start.cardpulse.domain.exception.OutboxEventCreationException;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class CancelAuthorizationDecisionService implements DecideCancelAuthorizationUseCase {

    private static final Logger log = LoggerFactory.getLogger(CancelAuthorizationDecisionService.class);

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private final ObjectMapper objectMapper;
    private final OutboxEventRepository outboxEventRepository;
    private final AuthorizationAuditPort auditPort;


    public CancelAuthorizationDecisionService(TransactionRepository transactionRepository,
                                              AccountRepository accountRepository,
                                              ObjectMapper objectMapper,
                                              OutboxEventRepository outboxEventRepository,
                                              AuthorizationAuditPort auditPort
    ) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
        this.objectMapper = objectMapper;
        this.outboxEventRepository = outboxEventRepository;
        this.auditPort = auditPort;
    }


    @Override
    @Transactional
    public TransactionReleaseResponse execute(UUID authorizationId, TransactionReleaseRequest request) {

        Transaction transaction = transactionRepository.findById(authorizationId).orElseThrow(AuthorizationNotFoundException::new);

        if (transaction.getStatus() != AuthorizationStatus.APROVADA) {

            log.warn(
                    "Status not valid. authorizationId={}, currentStatus={}",
                    authorizationId,
                    transaction.getStatus());

            throw new AuthorizationNotApprovedException();
        }

        AuthorizationReleaseDecision.restoreFunds(
                transaction,
                accountRepository
        );

        AuthorizationDecision decision = AuthorizationDecision.approvedCancellation();
        transaction.applyDecision(decision);


        try {

            auditPort.save(
                    new AuthorizationAuditDocument(
                            transaction.getId(),
                            "AUTHORIZATION_CANCELLED",
                            AuthorizationStatus.APROVADA.name(),
                            decision.status().name(),
                            decision.reasonCode().name(),
                            decision.decidedAt(),
                            transaction.getCorrelationId()
                    )
            );

        } catch (Exception ex) {

            log.error(
                    "Failed to persist audit. authorizationId={}",
                    transaction.getId(),
                    ex
            );
        }

        CancelAuthorizationDecidedEvent event =
                new CancelAuthorizationDecidedEvent(
                        UUID.randomUUID(),
                        "1.0",
                        transaction.getId(),
                        transaction.getOriginTransactionId(),
                        decision.status(),
                        decision.reasonCode(),
                        transaction.getAmount(),
                        transaction.getCurrency(),
                        decision.decidedAt(),
                        transaction.getCorrelationId()
                );

        try {
            String payload = objectMapper.writeValueAsString(event);

            OutboxEvent outboxEvent =
                    new OutboxEvent(
                            transaction.getId(),
                            "CancelAuthorizationDecided",
                            payload
                    );

            outboxEventRepository.save(outboxEvent);

        } catch (Exception e) {
            throw new OutboxEventCreationException();
        }


        return TransactionReleaseResponse.from(transaction, decision, request.getOriginOperationId());
    }

}
