package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.dto.transaction.TransactionResponse;

import java.util.UUID;

public interface DecideCreditAuthorizationUseCase {
    TransactionResponse execute(
            UUID authorizationId
    );
}