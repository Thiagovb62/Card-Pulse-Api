package com.start.cardpulse.domain.dto.operations;


import com.start.cardpulse.domain.enums.OutboxEventStatus;

import java.time.LocalDateTime;
import java.util.UUID;

public record PendingIntegrationResponse(
        UUID pendingId,
        UUID transactionId,
        String eventType,
        OutboxEventStatus status,
        Integer retryCount,
        LocalDateTime createdAt,
        LocalDateTime publishedAt
) {
}
