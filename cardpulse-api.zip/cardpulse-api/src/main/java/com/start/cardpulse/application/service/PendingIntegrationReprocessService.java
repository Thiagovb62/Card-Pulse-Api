package com.start.cardpulse.application.service;

import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.kafka.publisher.CancelAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.CreditAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.DebitAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.kafka.publisher.ReverseAuthorizationDecidedPublisher;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.application.usecases.ReprocessPendingIntegrationUseCae;
import com.start.cardpulse.domain.enums.OutboxEventStatus;
import com.start.cardpulse.domain.exception.OutboxEventCreationException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.UUID;


@Service
public class PendingIntegrationReprocessService implements ReprocessPendingIntegrationUseCae {

    private final OutboxEventRepository outboxEventRepository;
    private final CreditAuthorizationDecidedPublisher creditPublisher;
    private final DebitAuthorizationDecidedPublisher debitPublisher;
    private final CancelAuthorizationDecidedPublisher cancelPublisher;
    private final ReverseAuthorizationDecidedPublisher reversePublisher;

    public PendingIntegrationReprocessService(
            OutboxEventRepository outboxEventRepository, CreditAuthorizationDecidedPublisher creditPublisher, DebitAuthorizationDecidedPublisher debitPublisher, CancelAuthorizationDecidedPublisher cancelPublisher, ReverseAuthorizationDecidedPublisher reversePublisher
    ) {
        this.outboxEventRepository = outboxEventRepository;
        this.creditPublisher = creditPublisher;
        this.debitPublisher = debitPublisher;
        this.cancelPublisher = cancelPublisher;
        this.reversePublisher = reversePublisher;
    }

    @Override
    @Transactional
    public void execute(
            UUID pendingId,
            String requestedBy,
            String correlationId
    ) {

        OutboxEvent event =
                outboxEventRepository
                        .findById(pendingId)
                        .orElseThrow(
                                RuntimeException::new
                        );

        if (event.getStatus()
                == OutboxEventStatus.PUBLICADO) {

            return;
        }


        try {

            switch (event.getEventType()) {

                case "CreditAuthorizationDecided" -> creditPublisher.publish(
                        event.getTransactionId().toString(),
                        event.getPayload()
                ).get();

                case "DebitAuthorizationDecided" -> debitPublisher.publish(
                        event.getTransactionId().toString(),
                        event.getPayload()
                ).get();

                case "CancelAuthorizationDecided" -> cancelPublisher.publish(
                        event.getTransactionId().toString(),
                        event.getPayload()
                ).get();

                case "ReverseAuthorizationDecided" -> reversePublisher.publish(
                        event.getTransactionId().toString(),
                        event.getPayload()
                ).get();

                default -> throw new IllegalArgumentException(
                        "Unsupported event type: "
                                + event.getEventType()
                );
            }

            event.incrementRetry();

            event.markAsPublished();

            outboxEventRepository.save(
                    event
            );

        } catch (Exception ex) {

            event.incrementRetry();

            outboxEventRepository.save(event);

            throw new OutboxEventCreationException();
        }
    }
}
