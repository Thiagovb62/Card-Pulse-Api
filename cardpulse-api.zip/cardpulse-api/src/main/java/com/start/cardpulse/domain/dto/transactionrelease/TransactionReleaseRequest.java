package com.start.cardpulse.domain.dto.transactionrelease;


import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionReleaseRequest {

    @NotBlank
    String originOperationId;

    @NotBlank
    String reason;

}
