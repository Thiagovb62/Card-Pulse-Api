package com.start.cardpulse.domain.exception;

import org.springframework.http.HttpStatus;

public class InsufficientBalanceException extends BusinessException {


    public InsufficientBalanceException() {
        super("INSUFFICIENT_BALANCE", ValidationMessages.INSUFFICIENT_BALANCE, HttpStatus.UNPROCESSABLE_CONTENT);
    }


}
