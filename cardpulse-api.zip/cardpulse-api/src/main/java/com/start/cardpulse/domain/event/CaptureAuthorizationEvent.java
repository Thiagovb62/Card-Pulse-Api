package com.start.cardpulse.domain.event;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record CaptureAuthorizationEvent(
        UUID eventId,
        Integer version,
        UUID authorizationId,
        String captureId,
        BigDecimal amount,
        String currency,
        Instant ocurredAt,
        String originatorId,
        String correlationId

) {
}
