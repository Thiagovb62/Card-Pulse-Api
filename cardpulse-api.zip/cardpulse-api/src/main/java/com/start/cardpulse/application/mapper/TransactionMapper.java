package com.start.cardpulse.application.mapper;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.domain.dto.transaction.TransactionRequest;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

@Component
public class TransactionMapper {

    public Transaction fromTransaction(
            UUID authorizationId,
            String idempotencyKey,
            String correlationId,
            TransactionRequest request) {

        Instant now = Instant.now();

        Transaction transaction = new Transaction();

        transaction.setId(authorizationId);
        transaction.setIdempotencyKey(idempotencyKey);

        transaction.setCardToken(
                request.getCardToken()
        );

        transaction.setTransactionType(
                request.getTransactionType()
        );

        transaction.setAmount(
                request.getAmount()
        );

        transaction.setCurrency(
                request.getCurrency()
        );

        transaction.setMerchantId(
                request.getMerchantId()
        );

        transaction.setStatus(
                AuthorizationStatus.RECEBIDA
        );

        transaction.setCorrelationId(
                correlationId
        );

        transaction.setOccurredAt(
                Instant.parse(
                        request.getOccurredAt()
                )
        );

        transaction.setReceivedAt(now);

        transaction.setCreatedAt(now);

        transaction.setOriginTransactionId(
                authorizationId.toString()
        );

        return transaction;
    }
}