package com.start.cardpulse.domain.enums;

public enum AuthorizationStatus {
    RECEBIDA,
    APROVADA,
    CAPTURADA,
    NEGADA,
    CANCELADA,
    REVERTIDA
}
