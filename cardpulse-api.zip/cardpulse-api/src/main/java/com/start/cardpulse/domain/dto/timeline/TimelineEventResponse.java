package com.start.cardpulse.domain.dto.timeline;

import java.time.Instant;

public record TimelineEventResponse(
        String type,
        Instant timestamp
) {
}
