package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.dto.operations.PendingIntegrationResponse;

import java.util.List;

public interface GetPendingIntegrationsUseCase {
    List<PendingIntegrationResponse> execute();
}
