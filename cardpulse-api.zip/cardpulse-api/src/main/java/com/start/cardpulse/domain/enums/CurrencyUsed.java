package com.start.cardpulse.domain.enums;

public enum CurrencyUsed {
    BRL
}
