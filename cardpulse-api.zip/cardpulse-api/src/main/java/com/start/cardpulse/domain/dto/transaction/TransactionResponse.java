package com.start.cardpulse.domain.dto.transaction;

import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;
import com.start.cardpulse.domain.enums.TransactionType;

import java.time.Instant;
import java.util.UUID;

public record TransactionResponse(
        UUID authorizationId,
        AuthorizationStatus status,
        ReasonCode reasonCode,
        String reason,
        TransactionType transactionType,
        Instant receivedAt,
        Instant decidedAt,
        String correlationId,
        boolean idempotentReplay
) {

}
