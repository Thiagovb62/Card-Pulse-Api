package com.start.cardpulse.adapters.outbound.repository;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, UUID> {

    Transaction save(Transaction transaction);

    Optional<Transaction> findById(UUID id);
}
