package com.start.cardpulse.domain.exception;

import org.springframework.http.HttpStatus;

public class OutboxEventCreationException extends BusinessException {

    public OutboxEventCreationException() {
        super("OUTBOX_EVENT_CREATION_EXCEPTION", ValidationMessages.OUTBOX_EVENT_CREATION_EXCEPTION, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
