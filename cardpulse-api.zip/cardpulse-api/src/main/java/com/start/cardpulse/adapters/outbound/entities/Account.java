package com.start.cardpulse.adapters.outbound.entities;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "account")
public class Account {
    @Id
    @Column(nullable = false)
    private UUID id;

    @Column(nullable = false, unique = true)
    private String cardToken;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal balance;

    @Column(
            nullable = false,
            precision = 19,
            scale = 2
    )
    private BigDecimal availableCreditLimit;

    protected Account() {

    }

    public Account(UUID id, String cardToken, BigDecimal balance, BigDecimal availableCreditLimit) {
        this.id = id;
        this.cardToken = cardToken;
        this.balance = balance;
        this.availableCreditLimit = availableCreditLimit;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getCardToken() {
        return cardToken;
    }

    public void setCardToken(String cardToken) {
        this.cardToken = cardToken;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public BigDecimal getAvailableCreditLimit() {
        return availableCreditLimit;
    }

    public void setAvailableCreditLimit(BigDecimal availableCreditLimit) {
        this.availableCreditLimit = availableCreditLimit;
    }
}
