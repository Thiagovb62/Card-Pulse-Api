package com.start.cardpulse.domain.exception;

public final class ExceptionMessages {
    private ExceptionMessages() {

    }

    public static final String ONLY_APROVED_TRANSACTIONS_CAN_BE_CAPTURED = "Only approved transactions can be captured";

    public static final String ONLY_EQUAL_VALUES_FROM_CAPTURED = "Only equal values from captured";

    public static final String ONLY_IDENTICAL_COINS_ARE_CAPTURED = "Only identical coins are captured";

    public static final String INVALID_AUTHORIZATIONS = "Invalid Authorizations";
}
