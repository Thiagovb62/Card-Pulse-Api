package com.start.cardpulse.domain.dto.captureauthorization;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

public record CaptureAuthorizationRequest(


        @NotNull
        UUID authorizationId,

        @NotBlank
        String captureOriginId,

        @NotNull
        BigDecimal amount,

        @NotBlank
        String currency,

        @NotNull
        OffsetDateTime ocurredAt
) {
}
