package com.start.cardpulse.domain.event;

import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record CreditAuthorizationDecidedEvent(
        UUID eventId,
        String eventVersion,
        UUID authorizationId,
        String originTransactionId,
        AuthorizationStatus status,
        ReasonCode reasonCode,
        BigDecimal amount,
        String currency,
        Instant occurredAt,
        String correlationId

) {
}
