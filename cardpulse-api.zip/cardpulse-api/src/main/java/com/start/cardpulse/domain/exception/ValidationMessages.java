package com.start.cardpulse.domain.exception;

public final class ValidationMessages {

    private ValidationMessages() {
    }

    public static final String INSUFFICIENT_CREDIT_LIMIT = "Insufficient credit limit";
    public static final String CREDIT_APPROVED = "Credit approved";


    public static final String AUTHORIZATION_NOT_FOUND = "Autorização de transação não encontrada.";
    public static final String AUTHORIZATION_ALREADY_DECIDED = "A autorização já foi processada e não pode ser decidida novamente.";
    public static final String INSUFFICIENT_BALANCE = "Saldo indisponível  para realizar a operação.";
    public static final String APPROVED_TRANSACTION = "Transação aprovada. Saldo suficiente.";
    public static final String OUTBOX_EVENT_CREATION_EXCEPTION = "Falha ao serializar o evento de autorização";
    public static final String INVALID_AUTHORIZATION_STATUS = "Status de autorização inválida";

    public static final String APPROVED_CANCELLATION = "Transação aprovada cancelada com sucesso";
    public static final String APPROVED_REVERSION = "Transação aprovada revertida com sucesso";
    public static final String AUTHORIZATION_NOT_APPROVED = "O cancelamento ou a reversão da autorização é permitido apenas para transações aprovadas.";
    public static final String IDEMPOTENCY_CONFLICT = "Idempotency-key já foi utilizada com um operationId diferente.";


}