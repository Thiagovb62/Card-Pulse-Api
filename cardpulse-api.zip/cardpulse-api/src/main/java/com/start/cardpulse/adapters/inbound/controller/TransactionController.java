package com.start.cardpulse.adapters.inbound.controller;

import com.start.cardpulse.application.service.AuthorizationQueryService;
import com.start.cardpulse.application.service.TransactionService;
import com.start.cardpulse.application.usecases.GetAuthorizationTimelineUseCase;
import com.start.cardpulse.common.HeaderConstants;
import com.start.cardpulse.domain.dto.authorizationdetails.AuthorizationDetailsResponse;
import com.start.cardpulse.domain.dto.timeline.AuthorizationTimelineResponse;
import com.start.cardpulse.domain.dto.transaction.TransactionRequest;
import com.start.cardpulse.domain.dto.transaction.TransactionResponse;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/authorizations")
@Tag(name = "CardAuthorizations")
public class TransactionController {

    private final TransactionService service;
    private final AuthorizationQueryService authorizationQueryService;
    private final GetAuthorizationTimelineUseCase getAuthorizationTimelineUseCase;

    public TransactionController(TransactionService service, AuthorizationQueryService authorizationQueryService, GetAuthorizationTimelineUseCase getAuthorizationTimelineUseCase) {
        this.service = service;
        this.authorizationQueryService = authorizationQueryService;
        this.getAuthorizationTimelineUseCase = getAuthorizationTimelineUseCase;
    }

    @PutMapping()
    public ResponseEntity<TransactionResponse> process(
            @RequestHeader(HeaderConstants.IDEMPOTENCY_KEY) String idempotencyKey,
            @RequestHeader(
                    value = HeaderConstants.CORRELATION_ID,
                    required = false
            )
            String correlationId,
            @Valid @RequestBody TransactionRequest request
    ) {

        correlationId = Optional.ofNullable(correlationId).orElse(UUID.randomUUID().toString());

        TransactionResponse response =
                service.process(
                        idempotencyKey,
                        correlationId,
                        request
                );

        return ResponseEntity.ok(response);
    }


    @PostMapping("/{authorizationId}/cancellations")
    public ResponseEntity<TransactionReleaseResponse> cancel(
            @PathVariable UUID authorizationId,
            @RequestHeader(HeaderConstants.IDEMPOTENCY_KEY) String idempotencyKey,
            @Valid @RequestBody TransactionReleaseRequest request
    ) {

        TransactionReleaseResponse response =
                service.cancel(
                        authorizationId,
                        idempotencyKey,
                        request
                );

        return ResponseEntity.ok(response);
    }

    @PostMapping("/{authorizationId}/reversals")
    public ResponseEntity<TransactionReleaseResponse> reverse(
            @PathVariable UUID authorizationId,
            @RequestHeader(HeaderConstants.IDEMPOTENCY_KEY) String idempotencyKey,
            @Valid @RequestBody TransactionReleaseRequest request
    ) {


        TransactionReleaseResponse response =
                service.reverse(
                        authorizationId,
                        idempotencyKey,
                        request
                );

        return ResponseEntity.ok(response);
    }


    @GetMapping("/{authorizationId}")
    public ResponseEntity<AuthorizationDetailsResponse> getByAuthorizationId(
            @PathVariable UUID authorizationId
    ) {
        return ResponseEntity.ok(
                authorizationQueryService.execute(
                        authorizationId
                )
        );
    }

    @GetMapping("/{authorizationId}/timeline")
    public ResponseEntity<AuthorizationTimelineResponse> getTimeline(
            @PathVariable UUID authorizationId
    ) {

        return ResponseEntity.ok(
                getAuthorizationTimelineUseCase.execute(
                        authorizationId
                )
        );
    }


}