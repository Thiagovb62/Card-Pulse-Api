package com.start.cardpulse.adapters.outbound.repository;

import com.start.cardpulse.adapters.outbound.entities.Idempotency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;


@Repository
public interface IdempotencyRepository extends JpaRepository<Idempotency, UUID> {

    Optional<Idempotency> findByIdempotencyKey(String idempotencyKey);

    void deleteByExpiresAtBefore(Instant now);
}