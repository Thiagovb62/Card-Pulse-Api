package com.start.cardpulse.domain.validator;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationRequest;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.exception.ExceptionMessages;
import com.start.cardpulse.domain.exception.InvalidAuthorizationStatusException;
import org.springframework.stereotype.Component;

@Component
public class CaptureAuthorizationValidator {

    public void validate(
            Transaction transaction,
            CaptureAuthorizationRequest request) {

        validateStatus(transaction);
        validateAmount(transaction, request);
        validateCurrency(transaction, request);
    }

    private void validateStatus(Transaction transaction) {
        if (transaction.getStatus() != AuthorizationStatus.APROVADA) {
            throw new InvalidAuthorizationStatusException(
                    ExceptionMessages.ONLY_APROVED_TRANSACTIONS_CAN_BE_CAPTURED
            );
        }
    }

    private void validateAmount(
            Transaction transaction,
            CaptureAuthorizationRequest request) {

        if (transaction.getAmount().compareTo(request.amount()) != 0) {
            throw new InvalidAuthorizationStatusException(
                    ExceptionMessages.ONLY_EQUAL_VALUES_FROM_CAPTURED
            );
        }
    }

    private void validateCurrency(
            Transaction transaction,
            CaptureAuthorizationRequest request) {

        if (!transaction.getCurrency().equals(request.currency())) {
            throw new InvalidAuthorizationStatusException(
                    ExceptionMessages.ONLY_IDENTICAL_COINS_ARE_CAPTURED
            );
        }
    }

}
