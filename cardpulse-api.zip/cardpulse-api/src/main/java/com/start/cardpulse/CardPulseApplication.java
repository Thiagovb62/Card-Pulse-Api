package com.start.cardpulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CardPulseApplication {

    public static void main(String[] args) {
        SpringApplication.run(CardPulseApplication.class, args);
    }

}
