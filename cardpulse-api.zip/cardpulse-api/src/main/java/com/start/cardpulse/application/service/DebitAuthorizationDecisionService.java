package com.start.cardpulse.application.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.mongo.document.AuthorizationAuditDocument;
import com.start.cardpulse.adapters.outbound.repository.AccountRepository;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.ports.out.AuthorizationAuditPort;
import com.start.cardpulse.application.usecases.DecideDebitAuthorizationUseCase;
import com.start.cardpulse.domain.decision.AuthorizationDecision;
import com.start.cardpulse.domain.dto.transaction.TransactionResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.event.DebitAuthorizationDecidedEvent;
import com.start.cardpulse.domain.exception.AuthorizationAlreadyDecidedException;
import com.start.cardpulse.domain.exception.AuthorizationNotFoundException;
import com.start.cardpulse.domain.exception.OutboxEventCreationException;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;


@Service
public class DebitAuthorizationDecisionService implements DecideDebitAuthorizationUseCase {

    private static final Logger log = LoggerFactory.getLogger(DebitAuthorizationDecisionService.class);


    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private final OutboxEventRepository outboxEventRepository;
    private final ObjectMapper objectMapper;
    private final AuthorizationAuditPort auditPort;

    public DebitAuthorizationDecisionService(TransactionRepository transactionRepository,
                                             AccountRepository accountRepository,
                                             OutboxEventRepository outboxEventRepository,
                                             ObjectMapper objectMapper,
                                             AuthorizationAuditPort auditPort
    ) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
        this.outboxEventRepository = outboxEventRepository;
        this.objectMapper = objectMapper;
        this.auditPort = auditPort;
    }


    @Override
    @Transactional
    public TransactionResponse execute(UUID authorizationId) {

        Transaction transaction = transactionRepository.findById(authorizationId).orElseThrow(AuthorizationNotFoundException::new);

        if (transaction.getStatus() != AuthorizationStatus.RECEBIDA) {

            log.warn(
                    "Authorization already decided. authorizationId={}, currentStatus={}",
                    authorizationId,
                    transaction.getStatus());

            throw new AuthorizationAlreadyDecidedException();
        }

        boolean debited = accountRepository.debitIfSufficientBalance(transaction.getCardToken(), transaction.getAmount()) > 0;

        AuthorizationDecision decision =
                debited
                        ? AuthorizationDecision.approvedDebit()
                        : AuthorizationDecision.insufficientBalance();

        transaction.setStatus(decision.status());
        transaction.setReasonCode(decision.reasonCode());
        transaction.setReason(decision.reason());
        transaction.setDecidedAt(decision.decidedAt());


        try {

            auditPort.save(
                    new AuthorizationAuditDocument(
                            transaction.getId(),
                            "AUTHORIZATION_DECIDED",
                            AuthorizationStatus.RECEBIDA.name(),
                            decision.status().name(),
                            decision.reasonCode().name(),
                            decision.decidedAt(),
                            transaction.getCorrelationId()
                    )
            );

        } catch (Exception ex) {

            log.error(
                    "Failed to persist audit. authorizationId={}",
                    transaction.getId(),
                    ex
            );
        }

        DebitAuthorizationDecidedEvent event =
                new DebitAuthorizationDecidedEvent(
                        UUID.randomUUID(),
                        "1.0",
                        transaction.getId(),
                        transaction.getOriginTransactionId(),
                        decision.status(),
                        decision.reasonCode(),
                        transaction.getAmount(),
                        transaction.getCurrency(),
                        decision.decidedAt(),
                        transaction.getCorrelationId()
                );

        try {
            String payload = objectMapper.writeValueAsString(event);

            OutboxEvent outboxEvent =
                    new OutboxEvent(
                            transaction.getId(),
                            "DebitAuthorizationDecided",
                            payload
                    );

            outboxEventRepository.save(outboxEvent);

        } catch (Exception e) {
            throw new OutboxEventCreationException();
        }


        return new TransactionResponse(
                authorizationId,
                decision.status(),
                decision.reasonCode(),
                decision.reason(),
                transaction.getTransactionType(),
                transaction.getReceivedAt(),
                decision.decidedAt(),
                transaction.getCorrelationId(),
                false
        );
    }

}
