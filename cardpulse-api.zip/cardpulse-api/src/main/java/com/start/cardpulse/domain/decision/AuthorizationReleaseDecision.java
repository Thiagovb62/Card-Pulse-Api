package com.start.cardpulse.domain.decision;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.repository.AccountRepository;

public class AuthorizationReleaseDecision {

    public static void restoreFunds(
            Transaction transaction,
            AccountRepository accountRepository) {

        switch (transaction.getTransactionType()) {
            case DEBITO -> accountRepository.restoreBalance(
                    transaction.getCardToken(),
                    transaction.getAmount());

            case CREDITO -> accountRepository.restoreCreditLimit(
                    transaction.getCardToken(),
                    transaction.getAmount());
        }
    }
}
