package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseResponse;

import java.util.UUID;

public interface DecideCancelAuthorizationUseCase {
    TransactionReleaseResponse execute(UUID authorizationId, TransactionReleaseRequest request);
}
