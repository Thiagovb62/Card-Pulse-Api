package com.start.cardpulse.domain.dto.authorizationdetails;

import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;
import com.start.cardpulse.domain.enums.TransactionType;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public record AuthorizationDetailsResponse(
        UUID id,
        String originTransactionId,
        TransactionType transactionType,
        AuthorizationStatus status,
        BigDecimal amount,
        String currency,
        ReasonCode reasonCode,
        Instant occurredAt,
        Instant receivedAt,
        Instant decidedAt,
        List<String> correlationIds,
        Object metadata,
        boolean partial) {
}
