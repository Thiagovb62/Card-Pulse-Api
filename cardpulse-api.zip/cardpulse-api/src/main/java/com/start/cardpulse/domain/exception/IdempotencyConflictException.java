package com.start.cardpulse.domain.exception;

import org.springframework.http.HttpStatus;

public class IdempotencyConflictException extends BusinessException {

    public IdempotencyConflictException() {
        super("IDEMPOTENCY_CONFLICT", ValidationMessages.IDEMPOTENCY_CONFLICT, HttpStatus.CONFLICT);
    }
}
