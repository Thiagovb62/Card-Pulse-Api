package com.start.cardpulse.domain.enums;

public enum ReasonCode {
    DEBIT_APPROVED,
    CREDIT_APPROVED,
    CANCELLATION_APPROVED,
    REVERSION_APPROVED,
    INSUFFICIENT_CREDIT_LIMIT,
    INSUFFICIENT_BALANCE
}
