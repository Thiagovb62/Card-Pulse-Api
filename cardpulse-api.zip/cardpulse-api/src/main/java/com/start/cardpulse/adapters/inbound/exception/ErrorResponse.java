package com.start.cardpulse.adapters.inbound.exception;

import org.springframework.validation.FieldError;

import java.time.Instant;
import java.util.List;

public record ErrorResponse(
        Instant timestamp,
        int status,
        String errorCode,
        String message,
        String correlationId,
        List<FieldError> invalidFields
) {

    public ErrorResponse(
            int status,
            String errorCode,
            String message,
            String correlationId,
            List<FieldError> invalidFields) {

        this(
                Instant.now(),
                status,
                errorCode,
                message,
                correlationId,
                invalidFields
        );
    }
}