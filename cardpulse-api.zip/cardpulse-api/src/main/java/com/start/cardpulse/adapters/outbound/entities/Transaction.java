package com.start.cardpulse.adapters.outbound.entities;

import com.start.cardpulse.domain.decision.AuthorizationDecision;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;
import com.start.cardpulse.domain.enums.TransactionType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;


@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    private UUID id;

    @Column(name = "idempotency_key")
    private String idempotencyKey;

    @Column(name = "origin_transaction_id")
    private String originTransactionId;

    @Column(name = "card_token")
    private String cardToken;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type")
    private TransactionType transactionType;

    private BigDecimal amount;

    private String currency;

    @Column(name = "merchant_id")
    private String merchantId;

    @Enumerated(EnumType.STRING)
    private AuthorizationStatus status;

    @Column(name = "correlation_id")
    private String correlationId;

    @Column(name = "occurred_at")
    private Instant occurredAt;

    @Column(name = "received_at")
    private Instant receivedAt;

    @Column(name = "decided_at")
    private Instant decidedAt;

    @Column(name = "reason_code")
    @Enumerated(EnumType.STRING)
    private ReasonCode reasonCode;

    private String reason;

    @Column(name = "created_at")
    private Instant createdAt;

    public Transaction() {
    }

    public Transaction(UUID id, String idempotencyKey, String originTransactionId, String cardToken, TransactionType transactionType, BigDecimal amount, String currency, String merchantId, AuthorizationStatus status, String correlationId, Instant occurredAt, Instant receivedAt, Instant decidedAt, ReasonCode reasonCode, String reason, Instant createdAt) {
        this.id = id;
        this.idempotencyKey = idempotencyKey;
        this.originTransactionId = originTransactionId;
        this.cardToken = cardToken;
        this.transactionType = transactionType;
        this.amount = amount;
        this.currency = currency;
        this.merchantId = merchantId;
        this.status = status;
        this.correlationId = correlationId;
        this.occurredAt = occurredAt;
        this.receivedAt = receivedAt;
        this.decidedAt = decidedAt;
        this.reasonCode = reasonCode;
        this.reason = reason;
        this.createdAt = createdAt;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getIdempotencyKey() {
        return idempotencyKey;
    }

    public void setIdempotencyKey(String idempotencyKey) {
        this.idempotencyKey = idempotencyKey;
    }

    public String getOriginTransactionId() {
        return originTransactionId;
    }

    public void setOriginTransactionId(String originTransactionId) {
        this.originTransactionId = originTransactionId;
    }

    public String getCardToken() {
        return cardToken;
    }

    public void setCardToken(String cardToken) {
        this.cardToken = cardToken;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public AuthorizationStatus getStatus() {
        return status;
    }

    public void setStatus(AuthorizationStatus status) {
        this.status = status;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public Instant getOccurredAt() {
        return occurredAt;
    }

    public void setOccurredAt(Instant occurredAt) {
        this.occurredAt = occurredAt;
    }

    public Instant getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(Instant receivedAt) {
        this.receivedAt = receivedAt;
    }

    public Instant getDecidedAt() {
        return decidedAt;
    }

    public void setDecidedAt(Instant decidedAt) {
        this.decidedAt = decidedAt;
    }

    public ReasonCode getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(ReasonCode reasonCode) {
        this.reasonCode = reasonCode;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public void applyDecision(AuthorizationDecision decision) {
        this.status = decision.status();
        this.reasonCode = decision.reasonCode();
        this.reason = decision.reason();
        this.decidedAt = decision.decidedAt();
    }
}
