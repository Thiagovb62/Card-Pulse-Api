package com.start.cardpulse.domain.exception;

import org.springframework.http.HttpStatus;

public class AuthorizationNotApprovedException extends BusinessException {

    public AuthorizationNotApprovedException() {
        super("AUTHORIZATION_NOT_APPROVED", ValidationMessages.AUTHORIZATION_NOT_APPROVED, HttpStatus.BAD_REQUEST);
    }
}
