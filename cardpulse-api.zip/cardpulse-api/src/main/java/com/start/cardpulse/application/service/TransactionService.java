package com.start.cardpulse.application.service;

import com.start.cardpulse.adapters.outbound.entities.Idempotency;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.repository.IdempotencyRepository;
import com.start.cardpulse.adapters.outbound.repository.TransactionRepository;
import com.start.cardpulse.application.mapper.IdempotencyMapper;
import com.start.cardpulse.application.mapper.TransactionMapper;
import com.start.cardpulse.application.usecases.CreateTransactionUseCase;
import com.start.cardpulse.application.usecases.DecideCancelAuthorizationUseCase;
import com.start.cardpulse.application.usecases.DecideCreditAuthorizationUseCase;
import com.start.cardpulse.application.usecases.DecideDebitAuthorizationUseCase;
import com.start.cardpulse.application.usecases.DecideReverseAuthorizationUseCase;
import com.start.cardpulse.domain.dto.transaction.TransactionRequest;
import com.start.cardpulse.domain.dto.transaction.TransactionResponse;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseRequest;
import com.start.cardpulse.domain.dto.transactionrelease.TransactionReleaseResponse;
import com.start.cardpulse.domain.enums.TransactionType;
import com.start.cardpulse.domain.exception.IdempotencyConflictException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
public class TransactionService implements CreateTransactionUseCase {

    private final IdempotencyRepository idempotencyRepository;
    private final TransactionRepository transactionRepository;
    private final DecideDebitAuthorizationUseCase decideDebitAuthorizationUseCase;
    private final DecideCreditAuthorizationUseCase decideCreditAuthorizationUseCase;
    private final DecideCancelAuthorizationUseCase decideCancelAuthorizationUseCase;
    private final DecideReverseAuthorizationUseCase decideReverseAuthorizationUseCase;
    private final IdempotencyMapper idempotencyMapper;
    private final TransactionMapper transactionMapper;

    public TransactionService(IdempotencyRepository idempotencyRepository, TransactionRepository transactionRepository, DecideDebitAuthorizationUseCase decideDebitAuthorizationUseCase, DecideCreditAuthorizationUseCase decideCreditAuthorizationUseCase, DecideCancelAuthorizationUseCase decideCancelAuthorizationUseCase, DecideReverseAuthorizationUseCase decideReverseAuthorizationUseCase, IdempotencyMapper idempotencyMapper, TransactionMapper transactionMapper) {
        this.idempotencyRepository = idempotencyRepository;
        this.transactionRepository = transactionRepository;
        this.decideDebitAuthorizationUseCase = decideDebitAuthorizationUseCase;
        this.decideCreditAuthorizationUseCase = decideCreditAuthorizationUseCase;
        this.decideCancelAuthorizationUseCase = decideCancelAuthorizationUseCase;
        this.decideReverseAuthorizationUseCase = decideReverseAuthorizationUseCase;

        this.idempotencyMapper = idempotencyMapper;
        this.transactionMapper = transactionMapper;
    }

    @Override
    public TransactionResponse execute(
            TransactionRequest request,
            String idempotencyKey,
            String correlationId) {

        return process(
                idempotencyKey,
                correlationId,
                request
        );
    }

    @Transactional
    public TransactionResponse process(
            String idempotencyKey,
            String correlationId,
            TransactionRequest request) {

        Instant now = Instant.now();

        Optional<Idempotency> existing =
                idempotencyRepository.findByIdempotencyKey(
                        idempotencyKey
                );

        if (existing.isPresent()) {

            Idempotency entity = existing.get();

            if (entity.getExpiresAt().isAfter(now)) {

                return new TransactionResponse(
                        entity.getAuthorizationId(),
                        entity.getStatus(),
                        entity.getReasonCode(),
                        entity.getReason(),
                        entity.getType(),
                        entity.getReceivedAt(),
                        entity.getDecidedAt(),
                        entity.getCorrelationId(),
                        true
                );
            }

            idempotencyRepository.delete(entity);
        }

        UUID authorizationId = UUID.randomUUID();

        Transaction transaction =
                transactionMapper.fromTransaction(
                        authorizationId,
                        idempotencyKey,
                        correlationId,
                        request
                );

        transactionRepository.save(transaction);

        TransactionResponse response;

        if (request.getTransactionType()
                == TransactionType.CREDITO) {

            response =
                    decideCreditAuthorizationUseCase.execute(
                            authorizationId
                    );

        } else {

            response =
                    decideDebitAuthorizationUseCase.execute(
                            authorizationId
                    );
        }

        Idempotency entity =
                idempotencyMapper.fromTransaction(
                        idempotencyKey,
                        request,
                        response
                );


        idempotencyRepository.save(entity);

        return response;
    }


    @Transactional
    public TransactionReleaseResponse cancel(
            UUID authorizationId,
            String idempotencyKey,
            TransactionReleaseRequest request) {

        Instant now = Instant.now();

        Optional<Idempotency> existing =
                idempotencyRepository.findByIdempotencyKey(
                        idempotencyKey
                );

        if (existing.isPresent()) {

            Idempotency entity = existing.get();

            if (!entity.getExpiresAt().isAfter(now)) {

                idempotencyRepository.delete(entity);

            } else {

                validateIdempotency(entity, request);

                return new TransactionReleaseResponse(
                        entity.getAuthorizationId(),
                        entity.getOperationId(),
                        entity.getStatus(),
                        entity.getReasonCode(),
                        entity.getReason(),
                        entity.getValor(),
                        entity.getDecidedAt().toString(),
                        entity.getCorrelationId(),
                        true
                );
            }
        }

        Transaction transaction =
                transactionRepository.findById(
                        authorizationId
                ).orElseThrow();

        TransactionReleaseResponse response =
                decideCancelAuthorizationUseCase.execute(
                        authorizationId,
                        request
                );

        Idempotency idempotency =
                idempotencyMapper.fromRelease(
                        idempotencyKey,
                        request,
                        transaction,
                        response
                );

        idempotencyRepository.save(idempotency);

        return response;
    }


    @Transactional
    public TransactionReleaseResponse reverse(
            UUID authorizationId,
            String idempotencyKey,
            TransactionReleaseRequest request) {

        Instant now = Instant.now();

        Optional<Idempotency> existing =
                idempotencyRepository.findByIdempotencyKey(
                        idempotencyKey
                );

        if (existing.isPresent()) {

            Idempotency entity = existing.get();

            if (!entity.getExpiresAt().isAfter(now)) {

                idempotencyRepository.delete(entity);

            } else {

                validateIdempotency(entity, request);

                return new TransactionReleaseResponse(
                        entity.getAuthorizationId(),
                        entity.getOperationId(),
                        entity.getStatus(),
                        entity.getReasonCode(),
                        entity.getReason(),
                        entity.getValor(),
                        entity.getDecidedAt().toString(),
                        entity.getCorrelationId(),
                        true
                );
            }
        }

        Transaction transaction =
                transactionRepository.findById(
                        authorizationId
                ).orElseThrow();

        TransactionReleaseResponse response =
                decideReverseAuthorizationUseCase.execute(
                        authorizationId,
                        request
                );

        Idempotency idempotency =
                idempotencyMapper.fromRelease(
                        idempotencyKey,
                        request,
                        transaction,
                        response
                );

        idempotencyRepository.save(idempotency);

        return response;
    }

    private void validateIdempotency(
            Idempotency entity,
            TransactionReleaseRequest request) {

        if (!entity.getOperationId().equals(
                request.getOriginOperationId())) {

            throw new IdempotencyConflictException();
        }
    }

}
