package com.start.cardpulse.adapters.outbound.mongo.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.UUID;

@Document(collection = "authorization_audit")
public class AuthorizationAuditDocument {
    @Id
    private String auditId;

    private UUID authorizationId;
    private String occurrenceType;
    private String previousStatus;
    private String newStatus;
    private String reasonCode;
    private Instant occurredAt;
    private String correlationId;

    protected AuthorizationAuditDocument() {
    }

    public AuthorizationAuditDocument(
            UUID authorizationId,
            String occurrenceType,
            String previousStatus,
            String newStatus,
            String reasonCode,
            Instant occurredAt,
            String correlationId) {

        this.authorizationId = authorizationId;
        this.occurrenceType = occurrenceType;
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
        this.reasonCode = reasonCode;
        this.occurredAt = occurredAt;
        this.correlationId = correlationId;
    }

    public UUID getAuthorizationId() {
        return authorizationId;
    }

    public Instant getOccurredAt() {
        return occurredAt;
    }

    public String getOccurrenceType() {
        return occurrenceType;
    }

}
