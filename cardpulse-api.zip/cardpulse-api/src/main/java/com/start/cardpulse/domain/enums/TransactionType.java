package com.start.cardpulse.domain.enums;

public enum TransactionType {
    DEBITO,
    CREDITO
}
