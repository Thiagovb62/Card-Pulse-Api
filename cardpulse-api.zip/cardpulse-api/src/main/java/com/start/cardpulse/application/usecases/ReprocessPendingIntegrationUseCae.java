package com.start.cardpulse.application.usecases;

import java.util.UUID;

public interface ReprocessPendingIntegrationUseCae {
    void execute(
            UUID pendingId,
            String requestedBy,
            String correlationId
    );
}
