package com.start.cardpulse.domain.exception;

public class UnauthorizedTransactionException extends RuntimeException {
    public UnauthorizedTransactionException() {
        super("UNAUTHORIZED_TRANSACTION");
    }
}
