package com.start.cardpulse.application.usecases;

import com.start.cardpulse.domain.decision.AuthorizationDecision;

import java.math.BigDecimal;

public interface CreditAuthorizationUseCase {

    AuthorizationDecision authorize(
            String cardToken,
            BigDecimal amount
    );
}
