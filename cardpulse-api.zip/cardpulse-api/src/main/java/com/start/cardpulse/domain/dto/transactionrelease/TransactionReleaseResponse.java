package com.start.cardpulse.domain.dto.transactionrelease;

import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.domain.decision.AuthorizationDecision;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.ReasonCode;

import java.math.BigDecimal;
import java.util.UUID;

public record TransactionReleaseResponse(
        UUID authorizationId,
        String operationId,
        AuthorizationStatus status,
        ReasonCode reasonCode,
        String reason,
        BigDecimal reversedAmount,
        String occurredAt,
        String correlationId,
        boolean idempotentReplay


) {
    public static TransactionReleaseResponse from(
            Transaction transaction,
            AuthorizationDecision decision,
            String operationId) {

        return new TransactionReleaseResponse(
                transaction.getId(),
                operationId,
                decision.status(),
                decision.reasonCode(),
                decision.reason(),
                transaction.getAmount(),
                decision.decidedAt().toString(),
                transaction.getCorrelationId(),
                false
        );
    }
}
