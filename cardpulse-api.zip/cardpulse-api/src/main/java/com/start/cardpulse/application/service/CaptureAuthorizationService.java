package com.start.cardpulse.application.service;

import com.start.cardpulse.adapters.outbound.entities.OutboxEvent;
import com.start.cardpulse.adapters.outbound.entities.Transaction;
import com.start.cardpulse.adapters.outbound.mongo.document.AuthorizationAuditDocument;
import com.start.cardpulse.adapters.outbound.repository.CaptureAuthorizationRepository;
import com.start.cardpulse.adapters.outbound.repository.OutboxEventRepository;
import com.start.cardpulse.application.ports.out.AuthorizationAuditPort;
import com.start.cardpulse.application.usecases.CaptureAuthorizationUseCase;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationRequest;
import com.start.cardpulse.domain.dto.captureauthorization.CaptureAuthorizationResponse;
import com.start.cardpulse.domain.enums.AuthorizationStatus;
import com.start.cardpulse.domain.enums.EventType;
import com.start.cardpulse.domain.event.CaptureAuthorizationEvent;
import com.start.cardpulse.domain.exception.ExceptionMessages;
import com.start.cardpulse.domain.exception.InvalidAuthorizationStatusException;
import com.start.cardpulse.domain.exception.OutboxEventCreationException;
import com.start.cardpulse.domain.exception.UnauthorizedTransactionException;
import com.start.cardpulse.domain.validator.CaptureAuthorizationValidator;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tools.jackson.databind.ObjectMapper;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional

public class CaptureAuthorizationService implements CaptureAuthorizationUseCase {


    private static final Integer EVENT_VERSION = 1;
    private final CaptureAuthorizationRepository repository;
    private final CaptureAuthorizationValidator validator;
    private final AuthorizationAuditPort auditPort;
    private final OutboxEventRepository outboxEventRepository;
    private final ObjectMapper objectMapper;

    @Override
    public CaptureAuthorizationResponse execute(CaptureAuthorizationRequest request, String idempotencyKey, String correlationId) {


        UUID authorizationId = request.authorizationId();


        Transaction transaction = repository.findById(authorizationId)
                .orElseThrow(UnauthorizedTransactionException::new);

        validator.validate(transaction, request);

        OffsetDateTime capturedAt = OffsetDateTime.now();

        String previousStatus = transaction.getStatus().name();

        int rowsUpddate =
                repository.changeStatus(
                        transaction.getId(),
                        AuthorizationStatus.APROVADA,
                        AuthorizationStatus.CAPTURADA
                );

        if (rowsUpddate == 0) {
            throw new InvalidAuthorizationStatusException(
                    ExceptionMessages.INVALID_AUTHORIZATIONS
            );
        }
        AuthorizationAuditDocument audit = new AuthorizationAuditDocument(
                transaction.getId(),
                "AUTHORIZATION_CAPTURED",
                previousStatus,
                AuthorizationStatus.CAPTURADA.name(),
                null,
                Instant.now(),
                correlationId
        );
        try {
            auditPort.save(audit);

        } catch (Exception e) {
            log.error(
                    "Error registering audit. authorizationId={}",
                    transaction.getId(),
                    e);
        }

        CaptureAuthorizationEvent event = new CaptureAuthorizationEvent(
                UUID.randomUUID(),
                EVENT_VERSION,
                transaction.getId(),
                request.captureOriginId(),
                transaction.getAmount(),
                transaction.getCurrency(),
                Instant.now(),
                transaction.getMerchantId(),
                correlationId
        );

        try {
            String payload = objectMapper.writeValueAsString(event);

            OutboxEvent outboxEvent = new OutboxEvent(
                    transaction.getId(),
                    EventType.AUTHORIZATION_CAPTURED.getValue(),
                    payload
            );

            outboxEventRepository.save(outboxEvent);
        } catch (Exception e) {
            throw new OutboxEventCreationException();
        }


        return new CaptureAuthorizationResponse(
                transaction.getId(),
                request.captureOriginId(),
                AuthorizationStatus.CAPTURADA,
                transaction.getAmount(),
                transaction.getCurrency(),
                capturedAt,
                transaction.getCorrelationId(),
                false
        );


    }
}
